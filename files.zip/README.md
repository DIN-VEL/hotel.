# 🏨 HotelBill Pro — Full Stack Hotel Billing System

## Database Schema

### MongoDB (Mongoose)
```js
// User Collection
{
  _id: ObjectId,
  username: String (unique),
  passwordHash: String,    // bcrypt hashed
  name: String,
  role: "admin" | "staff",
  createdAt: Date
}

// MenuItem Collection
{
  _id: ObjectId,
  name: String,
  price: Number,
  category: "breakfast" | "lunch" | "dinner" | "beverages",
  available: Boolean,
  createdAt: Date,
  updatedAt: Date
}

// Bill Collection
{
  _id: ObjectId,
  billNo: String,          // INV-2024-0001 (auto-generated)
  customerName: String,
  items: [{ menuItemId, name, price, qty }],
  subtotal: Number,
  gst: Number,             // 5% CGST+SGST
  discount: Number,
  total: Number,
  paymentMode: "cash" | "upi" | "card",
  status: "paid" | "pending" | "cancelled",
  createdBy: ObjectId,
  createdAt: Date
}
```

### MySQL Schema
```sql
CREATE TABLE users (
  id VARCHAR(36) PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(100),
  role ENUM('admin','staff') DEFAULT 'staff',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE menu_items (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  category ENUM('breakfast','lunch','dinner','beverages') NOT NULL,
  available BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE bills (
  id VARCHAR(36) PRIMARY KEY,
  bill_no VARCHAR(20) UNIQUE NOT NULL,
  customer_name VARCHAR(100),
  subtotal DECIMAL(10,2) NOT NULL,
  gst DECIMAL(10,2) NOT NULL,
  discount DECIMAL(10,2) DEFAULT 0,
  total DECIMAL(10,2) NOT NULL,
  payment_mode ENUM('cash','upi','card') NOT NULL,
  status ENUM('paid','pending','cancelled') DEFAULT 'paid',
  created_by VARCHAR(36),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE bill_items (
  id VARCHAR(36) PRIMARY KEY,
  bill_id VARCHAR(36) NOT NULL,
  menu_item_id VARCHAR(36),
  item_name VARCHAR(100) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  qty INT NOT NULL,
  FOREIGN KEY (bill_id) REFERENCES bills(id) ON DELETE CASCADE
);
```

---

## Backend Setup (Node.js + Express)

### Install Dependencies
```bash
npm install express mongoose bcryptjs jsonwebtoken cors dotenv
```

### .env
```
PORT=5000
MONGO_URI=mongodb://localhost:27017/hotelbill
JWT_SECRET=your_secret_key_here
JWT_EXPIRES_IN=7d
```

### Key API Routes
```
POST /api/auth/login          → Login, returns JWT
GET  /api/menu                → List menu items
POST /api/menu                → Add item (admin)
PUT  /api/menu/:id            → Update item (admin)
DELETE /api/menu/:id          → Delete item (admin)
GET  /api/bills               → List all bills
POST /api/bills               → Create bill
GET  /api/reports/daily       → Daily report
GET  /api/reports/export      → Export CSV
```

### Auth Middleware (middleware/auth.js)
```js
const jwt = require('jsonwebtoken');
module.exports = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};
```

---

## Frontend Setup (React)

### Install Dependencies
```bash
npx create-react-app hotel-billing
cd hotel-billing
npm install axios recharts react-router-dom jspdf
```

### Default Credentials
| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | admin    | admin123  |
| Staff | staff    | staff123  |

---

## Features
- Secure login (bcrypt + JWT)
- Role-based access (Admin/Staff)
- Dashboard with sales charts
- Menu CRUD with daily updates
- Billing with GST (5%), discount, auto-totals
- Printable invoice (INV-YYYY-XXXX)
- Transaction history
- Daily/Weekly/Monthly reports
- CSV export
- Payment modes: Cash, UPI, Card
- Search & filter menu
- Toast notifications
- Responsive dark UI
