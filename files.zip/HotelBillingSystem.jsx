import { useState, useEffect, useCallback } from "react";

const generateId = () => Math.random().toString(36).substr(2, 9).toUpperCase();
const generateBillNo = (count) => `INV-${new Date().getFullYear()}-${String(count).padStart(4, "0")}`;
const formatCurrency = (n) => `₹${Number(n).toFixed(2)}`;
const formatDate = (d) => new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
const formatTime = (d) => new Date(d).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
const today = () => new Date().toISOString().split("T")[0];
const dayStart = (d) => { const x = new Date(d); x.setHours(0,0,0,0); return x; };
const weekStart = () => { const d = new Date(); d.setDate(d.getDate() - d.getDay()); d.setHours(0,0,0,0); return d; };
const monthStart = () => { const d = new Date(); d.setDate(1); d.setHours(0,0,0,0); return d; };
const hashPassword = (pw) => btoa(pw + "::hotel_salt_2024");
const verifyPassword = (pw, hash) => hashPassword(pw) === hash;

const INITIAL_USERS = [
  { id: "u1", username: "admin", passwordHash: hashPassword("admin123"), role: "admin", name: "Admin User" },
  { id: "u2", username: "staff", passwordHash: hashPassword("staff123"), role: "staff", name: "Staff Member" },
];

const INITIAL_MENU = [
  { id: "m1", name: "Masala Dosa", price: 80, category: "breakfast", available: true },
  { id: "m2", name: "Idli Sambar (4 pcs)", price: 60, category: "breakfast", available: true },
  { id: "m3", name: "Poori Bhaji", price: 70, category: "breakfast", available: true },
  { id: "m4", name: "Vada (2 pcs)", price: 50, category: "breakfast", available: true },
  { id: "m5", name: "Uthappam", price: 90, category: "breakfast", available: true },
  { id: "m6", name: "Veg Thali", price: 180, category: "lunch", available: true },
  { id: "m7", name: "Non-Veg Thali", price: 250, category: "lunch", available: true },
  { id: "m8", name: "Chicken Biryani", price: 220, category: "lunch", available: true },
  { id: "m9", name: "Paneer Butter Masala", price: 160, category: "lunch", available: true },
  { id: "m10", name: "Dal Fry + Rice", price: 120, category: "lunch", available: true },
  { id: "m11", name: "Mutton Curry", price: 280, category: "dinner", available: true },
  { id: "m12", name: "Tandoori Chicken (half)", price: 300, category: "dinner", available: true },
  { id: "m13", name: "Naan", price: 40, category: "dinner", available: true },
  { id: "m14", name: "Palak Paneer", price: 170, category: "dinner", available: true },
  { id: "m15", name: "Fish Curry", price: 240, category: "dinner", available: true },
  { id: "m16", name: "Filter Coffee", price: 30, category: "beverages", available: true },
  { id: "m17", name: "Masala Chai", price: 25, category: "beverages", available: true },
  { id: "m18", name: "Fresh Lime Soda", price: 50, category: "beverages", available: true },
  { id: "m19", name: "Mango Lassi", price: 80, category: "beverages", available: true },
  { id: "m20", name: "Mineral Water", price: 20, category: "beverages", available: true },
];

const CATEGORIES = ["breakfast", "lunch", "dinner", "beverages"];
const CATEGORY_COLORS = { breakfast: "#f59e0b", lunch: "#10b981", dinner: "#6366f1", beverages: "#3b82f6" };
const CATEGORY_ICONS = { breakfast: "☀️", lunch: "🍱", dinner: "🌙", beverages: "☕" };
const GST_RATE = 0.05;

const generateSeedBills = () => {
  const bills = [];
  const now = Date.now();
  const items = [
    [{ id: "m1", name: "Masala Dosa", price: 80, qty: 2 }, { id: "m16", name: "Filter Coffee", price: 30, qty: 2 }],
    [{ id: "m6", name: "Veg Thali", price: 180, qty: 3 }],
    [{ id: "m8", name: "Chicken Biryani", price: 220, qty: 2 }, { id: "m18", name: "Fresh Lime Soda", price: 50, qty: 2 }],
    [{ id: "m12", name: "Tandoori Chicken (half)", price: 300, qty: 1 }, { id: "m13", name: "Naan", price: 40, qty: 4 }],
    [{ id: "m2", name: "Idli Sambar (4 pcs)", price: 60, qty: 4 }, { id: "m17", name: "Masala Chai", price: 25, qty: 4 }],
    [{ id: "m7", name: "Non-Veg Thali", price: 250, qty: 2 }, { id: "m19", name: "Mango Lassi", price: 80, qty: 2 }],
    [{ id: "m11", name: "Mutton Curry", price: 280, qty: 1 }, { id: "m13", name: "Naan", price: 40, qty: 3 }],
    [{ id: "m9", name: "Paneer Butter Masala", price: 160, qty: 2 }, { id: "m10", name: "Dal Fry + Rice", price: 120, qty: 2 }],
  ];
  const offsets = [2*3600000, 5*3600000, 8*3600000, 14*3600000, 26*3600000, 48*3600000, 72*3600000, 120*3600000];
  offsets.forEach((offset, i) => {
    const billItems = items[i];
    const subtotal = billItems.reduce((s, it) => s + it.price * it.qty, 0);
    const gst = +(subtotal * 0.05).toFixed(2);
    const total = subtotal + gst;
    bills.push({ id: generateId(), billNo: generateBillNo(i+1), createdAt: now - offset, items: billItems, subtotal, gst, discount: 0, total, customerName: ["Table 1","Table 2","Table 3","Table 4","Table 5","Table 6","Table 7","Table 8"][i], paymentMode: ["cash","upi","card"][i%3], status: "paid" });
  });
  return bills;
};

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0f0f12;--surface:#18181f;--surface2:#22222c;--surface3:#2a2a38;--border:rgba(255,255,255,0.07);--border2:rgba(255,255,255,0.12);--text:#f0eff5;--muted:#8885a0;--accent:#e8b86d;--accent2:#c9965a;--green:#4ade80;--red:#f87171;--blue:#60a5fa;--purple:#a78bfa;--sidebar-w:220px;--radius:12px;--radius-sm:8px}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;min-height:100vh;font-size:14px}
::-webkit-scrollbar{width:4px;height:4px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:var(--surface3);border-radius:99px}
.login-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;background:var(--bg);position:relative;overflow:hidden}
.login-bg{position:absolute;inset:0;background:radial-gradient(ellipse 60% 50% at 50% 0%,rgba(232,184,109,0.08) 0%,transparent 70%);pointer-events:none}
.login-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,0.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.025) 1px,transparent 1px);background-size:40px 40px;pointer-events:none}
.login-card{width:400px;background:var(--surface);border:1px solid var(--border2);border-radius:20px;padding:40px;position:relative;z-index:1}
.login-logo{text-align:center;margin-bottom:28px}.login-logo h1{font-family:'DM Serif Display',serif;font-size:26px;color:var(--accent)}.login-logo p{color:var(--muted);font-size:12px;margin-top:4px}
.form-group{margin-bottom:16px}.form-group label{display:block;font-size:11px;font-weight:600;letter-spacing:0.5px;text-transform:uppercase;color:var(--muted);margin-bottom:7px}
.form-control{width:100%;background:var(--surface2);border:1px solid var(--border2);border-radius:var(--radius-sm);padding:11px 13px;color:var(--text);font-size:13px;font-family:inherit;transition:border-color 0.2s;outline:none}
.form-control:focus{border-color:var(--accent)}.form-control::placeholder{color:var(--muted)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:11px 18px;border-radius:var(--radius-sm);border:none;cursor:pointer;font-size:13px;font-weight:600;font-family:inherit;transition:all 0.2s}
.btn-primary{background:var(--accent);color:#1a1208}.btn-primary:hover{background:var(--accent2);transform:translateY(-1px)}
.btn-secondary{background:var(--surface2);color:var(--text);border:1px solid var(--border2)}.btn-secondary:hover{background:var(--surface3)}
.btn-danger{background:rgba(248,113,113,0.15);color:var(--red);border:1px solid rgba(248,113,113,0.3)}.btn-danger:hover{background:rgba(248,113,113,0.25)}
.btn-success{background:rgba(74,222,128,0.15);color:var(--green);border:1px solid rgba(74,222,128,0.3)}.btn-success:hover{background:rgba(74,222,128,0.25)}
.btn-sm{padding:6px 12px;font-size:12px}.btn-full{width:100%}
.login-creds{margin-top:16px;background:var(--surface2);border-radius:var(--radius-sm);padding:12px;font-size:12px;color:var(--muted);line-height:1.8}
.login-creds strong{color:var(--text)}.error-msg{background:rgba(248,113,113,0.1);border:1px solid rgba(248,113,113,0.3);color:var(--red);border-radius:var(--radius-sm);padding:9px 13px;font-size:12px;margin-bottom:14px}
.app-layout{display:flex;min-height:100vh}
.sidebar{width:var(--sidebar-w);background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;top:0;left:0;height:100vh;z-index:100}
.sidebar-brand{padding:20px 16px 18px;border-bottom:1px solid var(--border)}.sidebar-brand h2{font-family:'DM Serif Display',serif;font-size:18px;color:var(--accent)}.sidebar-brand p{font-size:10px;color:var(--muted);margin-top:2px}
.sidebar-nav{flex:1;padding:12px 10px;display:flex;flex-direction:column;gap:2px;overflow-y:auto}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:var(--radius-sm);cursor:pointer;font-size:13px;font-weight:500;color:var(--muted);transition:all 0.15s}
.nav-item:hover{background:var(--surface2);color:var(--text)}.nav-item.active{background:rgba(232,184,109,0.12);color:var(--accent)}
.nav-icon{font-size:15px;width:18px;text-align:center}
.sidebar-footer{padding:14px 10px;border-top:1px solid var(--border)}
.user-info{display:flex;align-items:center;gap:9px;margin-bottom:10px}
.user-avatar{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#1a1208;flex-shrink:0}
.user-name{font-size:12px;font-weight:600}.user-role{font-size:10px;color:var(--muted);text-transform:capitalize}
.main-content{margin-left:var(--sidebar-w);flex:1;padding:24px;min-height:100vh;overflow-y:auto}
.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:22px}
.topbar-title{font-family:'DM Serif Display',serif;font-size:23px;letter-spacing:-0.3px}
.time-badge{font-size:11px;color:var(--muted);background:var(--surface);border:1px solid var(--border);border-radius:99px;padding:5px 12px}
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:18px}
.stat-label{font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:var(--muted);margin-bottom:7px}
.stat-value{font-size:22px;font-weight:700;font-family:'DM Serif Display',serif;letter-spacing:-0.5px}
.stat-sub{font-size:11px;color:var(--muted);margin-top:3px}.stat-icon{font-size:24px;float:right;margin-top:-2px;opacity:0.8}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px}
.card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:20px}
.card-title{font-weight:600;font-size:14px}.card-subtitle{font-size:11px;color:var(--muted);margin-top:2px}
.bar-chart{display:flex;align-items:flex-end;gap:6px;height:110px}
.bar-col{flex:1;display:flex;flex-direction:column;align-items:center;gap:5px;height:100%;justify-content:flex-end}
.bar{width:100%;border-radius:5px 5px 0 0;background:var(--accent);opacity:0.8;min-height:3px}
.bar-label{font-size:10px;color:var(--muted)}.bar-val{font-size:9px;color:var(--accent);font-weight:600}
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse}
th{text-align:left;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:var(--muted);padding:9px 12px;border-bottom:1px solid var(--border)}
td{padding:10px 12px;border-bottom:1px solid var(--border);font-size:13px;vertical-align:middle}
tr:last-child td{border-bottom:none}tr:hover td{background:rgba(255,255,255,0.02)}
.badge{display:inline-flex;align-items:center;padding:2px 8px;border-radius:99px;font-size:10px;font-weight:600}
.badge-success{background:rgba(74,222,128,0.12);color:var(--green)}.badge-info{background:rgba(96,165,250,0.12);color:var(--blue)}
.menu-controls{display:flex;gap:10px;margin-bottom:14px;align-items:center}
.search-input{flex:1;background:var(--surface2);border:1px solid var(--border2);border-radius:var(--radius-sm);padding:9px 13px;color:var(--text);font-size:13px;font-family:inherit;outline:none}
.search-input:focus{border-color:var(--accent)}
.cat-filter{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px}
.cat-btn{padding:5px 12px;border-radius:99px;border:1px solid var(--border2);background:transparent;color:var(--muted);font-size:11px;font-weight:500;cursor:pointer;transition:all 0.15s;font-family:inherit}
.cat-btn.active{background:var(--accent);color:#1a1208;border-color:var(--accent)}
.menu-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(175px,1fr));gap:12px}
.menu-card{background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius);padding:14px;position:relative;transition:border-color 0.2s}
.menu-card:hover{border-color:var(--border2)}.menu-card.unavailable{opacity:0.5}
.menu-card-name{font-weight:600;font-size:13px;margin-bottom:5px}.menu-card-price{font-size:18px;font-weight:700;color:var(--accent);font-family:'DM Serif Display',serif}
.menu-card-actions{display:flex;gap:5px;margin-top:10px}
.add-item-btn{width:100%;background:rgba(232,184,109,0.08);border:1px dashed rgba(232,184,109,0.3);border-radius:var(--radius);padding:20px;cursor:pointer;color:var(--accent);font-size:12px;font-weight:500;font-family:inherit;display:flex;align-items:center;justify-content:center;gap:7px;transition:all 0.2s}
.add-item-btn:hover{background:rgba(232,184,109,0.12)}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.75);backdrop-filter:blur(4px);z-index:1000;display:flex;align-items:center;justify-content:center;padding:20px}
.modal{background:var(--surface);border:1px solid var(--border2);border-radius:16px;padding:28px;width:460px;max-width:100%;max-height:90vh;overflow-y:auto}
.modal h2{font-family:'DM Serif Display',serif;font-size:20px;margin-bottom:20px}
.modal-actions{display:flex;gap:9px;margin-top:20px;justify-content:flex-end}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
select.form-control option{background:var(--surface)}
.billing-layout{display:grid;grid-template-columns:1fr 360px;gap:16px;height:calc(100vh - 130px)}
.billing-menu{overflow-y:auto}.billing-sidebar-panel{display:flex;flex-direction:column;gap:14px;overflow-y:auto}
.bill-item-row{display:flex;align-items:center;gap:8px;padding:9px 0;border-bottom:1px solid var(--border)}
.bill-item-name{flex:1;font-size:12px;font-weight:500}.bill-item-price{font-size:11px;color:var(--muted)}
.qty-control{display:flex;align-items:center;gap:7px}
.qty-btn{width:24px;height:24px;border-radius:50%;border:1px solid var(--border2);background:var(--surface2);color:var(--text);cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center}
.qty-btn:hover{border-color:var(--accent);color:var(--accent)}.qty-display{font-size:13px;font-weight:600;min-width:18px;text-align:center}
.bill-total-row{display:flex;justify-content:space-between;font-size:13px;padding:4px 0;color:var(--muted)}
.bill-total-row.grand{font-size:15px;font-weight:700;color:var(--text);padding-top:10px;border-top:1px solid var(--border);margin-top:4px}
.bill-total-row.grand .amt{color:var(--accent)}
.menu-item-select{cursor:pointer;border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px;background:var(--surface2);transition:all 0.15s}
.menu-item-select:hover{border-color:var(--accent)}.menu-item-select.in-cart{border-color:var(--accent);background:rgba(232,184,109,0.06)}
.menu-item-select .item-n{font-weight:500;font-size:12px}.menu-item-select .item-p{font-size:15px;font-weight:700;color:var(--accent);font-family:'DM Serif Display',serif}
.payment-modes{display:flex;gap:7px}
.pay-mode{flex:1;padding:9px;border-radius:var(--radius-sm);border:1px solid var(--border2);background:var(--surface2);cursor:pointer;text-align:center;font-size:11px;font-weight:500;font-family:inherit;color:var(--muted);transition:all 0.15s}
.pay-mode.active{border-color:var(--accent);color:var(--accent);background:rgba(232,184,109,0.08)}
.invoice-modal{width:560px}.invoice-header{text-align:center;margin-bottom:20px;padding-bottom:16px;border-bottom:2px solid var(--border)}
.invoice-header h2{font-family:'DM Serif Display',serif;font-size:26px;color:var(--accent)}
.invoice-meta{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:16px;font-size:11px;color:var(--muted)}
.invoice-meta span strong{color:var(--text)}.invoice-totals{border-top:1px solid var(--border);padding-top:10px;font-size:12px}
.invoice-items-table{width:100%;margin-bottom:14px;font-size:12px}
.report-tabs{display:flex;gap:4px;background:var(--surface2);border-radius:var(--radius-sm);padding:4px;margin-bottom:20px;width:fit-content}
.report-tab{padding:7px 18px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:500;color:var(--muted);transition:all 0.15s;border:none;background:transparent;font-family:inherit}
.report-tab.active{background:var(--accent);color:#1a1208}
.donut-wrap{display:flex;align-items:center;gap:20px}
.legend-item{display:flex;align-items:center;gap:7px;font-size:12px;margin-bottom:7px}
.legend-dot{width:9px;height:9px;border-radius:50%;flex-shrink:0}
.toggle{position:relative;width:38px;height:21px;display:inline-block}
.toggle input{opacity:0;width:0;height:0}.toggle-slider{position:absolute;inset:0;background:var(--surface3);border-radius:99px;cursor:pointer;transition:0.2s}
.toggle-slider::before{content:'';position:absolute;width:15px;height:15px;left:3px;top:3px;background:var(--muted);border-radius:50%;transition:0.2s}
.toggle input:checked+.toggle-slider{background:rgba(74,222,128,0.2)}.toggle input:checked+.toggle-slider::before{transform:translateX(17px);background:var(--green)}
.empty-state{text-align:center;padding:36px 20px;color:var(--muted)}.empty-state .icon{font-size:40px;margin-bottom:10px}.empty-state p{font-size:13px}
.toast-container{position:fixed;bottom:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:7px}
.toast{background:var(--surface2);border:1px solid var(--border2);border-radius:var(--radius-sm);padding:12px 16px;font-size:12px;display:flex;align-items:center;gap:9px;animation:slideIn 0.3s ease;min-width:240px}
.toast.success{border-color:rgba(74,222,128,0.3)}.toast.error{border-color:rgba(248,113,113,0.3)}
@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}
.section-divider{height:1px;background:var(--border);margin:16px 0}
.text-accent{color:var(--accent)}.text-muted{color:var(--muted)}.text-green{color:var(--green)}.text-red{color:var(--red)}
.fw-600{font-weight:600}.fs-12{font-size:12px}.fs-13{font-size:13px}.mt-8{margin-top:8px}.mt-16{margin-top:16px}.mb-16{margin-bottom:16px}
.flex{display:flex;align-items:center}.flex-between{display:flex;align-items:center;justify-content:space-between}.gap-8{gap:8px}.gap-12{gap:12px}
`;

function useToast() {
  const [toasts, setToasts] = useState([]);
  const add = useCallback((msg, type = "success") => {
    const id = Date.now();
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3000);
  }, []);
  const remove = useCallback((id) => setToasts(p => p.filter(t => t.id !== id)), []);
  return { toasts, add, remove };
}

function Toast({ toasts }) {
  return (
    <div className="toast-container">
      {toasts.map(t => (
        <div key={t.id} className={`toast ${t.type}`}>
          <span style={{ color: t.type === "success" ? "var(--green)" : "var(--red)" }}>{t.type === "success" ? "✓" : "✗"}</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const handleSubmit = () => {
    const user = INITIAL_USERS.find(u => u.username === username);
    if (!user || !verifyPassword(password, user.passwordHash)) { setError("Invalid username or password."); return; }
    onLogin(user);
  };
  return (
    <div className="login-wrap">
      <div className="login-bg"/><div className="login-grid"/>
      <div className="login-card">
        <div className="login-logo"><h1>🏨 HotelBill Pro</h1><p>Hotel Billing Management System</p></div>
        {error && <div className="error-msg">{error}</div>}
        <div className="form-group"><label>Username</label><input className="form-control" value={username} onChange={e=>setUsername(e.target.value)} placeholder="Enter username" onKeyDown={e=>e.key==="Enter"&&handleSubmit()}/></div>
        <div className="form-group"><label>Password</label><input className="form-control" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter password" onKeyDown={e=>e.key==="Enter"&&handleSubmit()}/></div>
        <button className="btn btn-primary btn-full" onClick={handleSubmit}>Sign In →</button>
        <div className="login-creds"><div><strong>Admin:</strong> admin / admin123</div><div><strong>Staff:</strong> staff / staff123</div></div>
      </div>
    </div>
  );
}

const NAV = [
  { id: "dashboard", icon: "◈", label: "Dashboard" },
  { id: "menu", icon: "📋", label: "Menu" },
  { id: "billing", icon: "🧾", label: "New Bill" },
  { id: "transactions", icon: "💳", label: "Transactions" },
  { id: "reports", icon: "📊", label: "Reports" },
  { id: "settings", icon: "⚙", label: "Settings" },
];

function Sidebar({ page, setPage, user, onLogout }) {
  return (
    <div className="sidebar">
      <div className="sidebar-brand"><h2>🏨 HotelBill</h2><p>Management System</p></div>
      <nav className="sidebar-nav">
        {NAV.map(n => (
          <div key={n.id} className={`nav-item ${page===n.id?"active":""}`} onClick={()=>setPage(n.id)}>
            <span className="nav-icon">{n.icon}</span>{n.label}
          </div>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="user-info">
          <div className="user-avatar">{user.name[0]}</div>
          <div><div className="user-name">{user.name}</div><div className="user-role">{user.role}</div></div>
        </div>
        <button className="btn btn-secondary btn-sm btn-full" onClick={onLogout}>Logout</button>
      </div>
    </div>
  );
}

function Dashboard({ bills, menu }) {
  const [clock, setClock] = useState(new Date());
  useEffect(() => { const t = setInterval(()=>setClock(new Date()),1000); return ()=>clearInterval(t); }, []);
  const now = Date.now();
  const todayBills = bills.filter(b => dayStart(b.createdAt) >= dayStart(now));
  const weekBills = bills.filter(b => b.createdAt >= weekStart());
  const monthBills = bills.filter(b => b.createdAt >= monthStart());
  const sum = arr => arr.reduce((s,b)=>s+b.total,0);
  const catSales = {};
  bills.forEach(b => b.items.forEach(it => { const m=menu.find(x=>x.id===it.id); const cat=m?.category||"other"; catSales[cat]=(catSales[cat]||0)+it.price*it.qty; }));
  const itemCounts = {};
  bills.forEach(b => b.items.forEach(it => { itemCounts[it.name]=(itemCounts[it.name]||0)+it.qty; }));
  const popular = Object.entries(itemCounts).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const days7 = Array.from({length:7},(_,i)=>{
    const d=new Date(); d.setDate(d.getDate()-(6-i)); d.setHours(0,0,0,0);
    const next=new Date(d); next.setDate(next.getDate()+1);
    return { label:d.toLocaleDateString("en-IN",{weekday:"short"}), val:sum(bills.filter(b=>b.createdAt>=d.getTime()&&b.createdAt<next.getTime())) };
  });
  const maxDay = Math.max(...days7.map(d=>d.val),1);
  const totalCatSales = Object.values(catSales).reduce((a,b)=>a+b,0)||1;
  const catColors = {breakfast:"#f59e0b",lunch:"#10b981",dinner:"#6366f1",beverages:"#3b82f6"};
  return (
    <div>
      <div className="topbar">
        <div className="topbar-title">Dashboard</div>
        <div className="time-badge">{clock.toLocaleDateString("en-IN",{weekday:"short",day:"2-digit",month:"short"})} · {clock.toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit",second:"2-digit"})}</div>
      </div>
      <div className="stats-grid">
        {[{label:"Today's Sales",val:sum(todayBills),icon:"☀️",sub:`${todayBills.length} bills`,color:"#f59e0b"},{label:"Weekly Sales",val:sum(weekBills),icon:"📅",sub:`${weekBills.length} bills`,color:"#10b981"},{label:"Monthly Sales",val:sum(monthBills),icon:"📆",sub:`${monthBills.length} bills`,color:"#6366f1"},{label:"Active Menu",val:menu.filter(m=>m.available).length,icon:"🍽️",sub:`${menu.length} total`,color:"#3b82f6",raw:true}].map((s,i)=>(
          <div key={i} className="stat-card"><div className="stat-icon">{s.icon}</div><div className="stat-label">{s.label}</div><div className="stat-value" style={{color:s.color}}>{s.raw?s.val:formatCurrency(s.val)}</div><div className="stat-sub">{s.sub}</div></div>
        ))}
      </div>
      <div className="grid-2">
        <div className="card">
          <div style={{marginBottom:14}}><div className="card-title">Weekly Revenue</div><div className="card-subtitle">Last 7 days</div></div>
          <div className="bar-chart">
            {days7.map((d,i)=>(
              <div key={i} className="bar-col">
                <div className="bar-val">{d.val>0?`₹${Math.round(d.val/100)/10}k`:""}</div>
                <div className="bar" style={{height:`${Math.max((d.val/maxDay)*88,3)}%`,background:i===6?"var(--accent)":"rgba(232,184,109,0.4)"}}/>
                <div className="bar-label">{d.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <div style={{marginBottom:14}}><div className="card-title">Sales by Category</div></div>
          <div className="donut-wrap">
            <svg width="110" height="110" viewBox="0 0 110 110">
              {(()=>{let offset=0;return Object.entries(catSales).map(([cat,val])=>{const pct=val/totalCatSales;const da=`${pct*251} ${251-pct*251}`;const el=<circle key={cat} cx="55" cy="55" r="40" fill="none" stroke={catColors[cat]||"#999"} strokeWidth="18" strokeDasharray={da} strokeDashoffset={-offset*2.51} style={{transform:"rotate(-90deg)",transformOrigin:"55px 55px"}}/>;offset+=pct*100;return el;})})()}
              <circle cx="55" cy="55" r="27" fill="var(--surface)"/>
              <text x="55" y="60" textAnchor="middle" fill="var(--accent)" fontSize="14" fontWeight="700" fontFamily="DM Serif Display">₹</text>
            </svg>
            <div>
              {Object.entries(catSales).map(([cat,val])=>(
                <div key={cat} className="legend-item"><div className="legend-dot" style={{background:catColors[cat]}}/><span className="text-muted">{cat}</span><span className="fw-600" style={{marginLeft:6}}>{formatCurrency(val)}</span></div>
              ))}
              {Object.keys(catSales).length===0&&<div className="text-muted fs-12">No data yet</div>}
            </div>
          </div>
        </div>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title" style={{marginBottom:14}}>Popular Items</div>
          {popular.length===0?<div className="empty-state"><div className="icon">🍽️</div><p>No sales yet</p></div>:
          <table><thead><tr><th>#</th><th>Item</th><th>Sold</th></tr></thead>
          <tbody>{popular.map(([name,qty],i)=>(
            <tr key={i}><td className="text-muted">{i+1}</td><td className="fw-600">{name}</td><td><span className="badge badge-success">{qty}</span></td></tr>
          ))}</tbody></table>}
        </div>
        <div className="card">
          <div className="card-title" style={{marginBottom:14}}>Recent Transactions</div>
          {bills.length===0?<div className="empty-state"><div className="icon">🧾</div><p>No bills yet</p></div>:
          <table><thead><tr><th>Bill</th><th>Amount</th><th>Time</th></tr></thead>
          <tbody>{[...bills].sort((a,b)=>b.createdAt-a.createdAt).slice(0,6).map(b=>(
            <tr key={b.id}><td><div className="fw-600">{b.billNo}</div><div className="fs-12 text-muted">{b.customerName}</div></td><td className="text-accent fw-600">{formatCurrency(b.total)}</td><td className="text-muted fs-12">{formatTime(b.createdAt)}</td></tr>
          ))}</tbody></table>}
        </div>
      </div>
    </div>
  );
}

function MenuManagement({ menu, setMenu, user, toast }) {
  const [search, setSearch] = useState(""); const [catFilter, setCatFilter] = useState("all"); const [modal, setModal] = useState(null); const [form, setForm] = useState({name:"",price:"",category:"breakfast"});
  const filtered = menu.filter(m=>(catFilter==="all"||m.category===catFilter)&&m.name.toLowerCase().includes(search.toLowerCase()));
  const save = () => {
    if(!form.name.trim()||!form.price) return toast.add("Fill all fields","error");
    const price=parseFloat(form.price); if(isNaN(price)||price<=0) return toast.add("Invalid price","error");
    if(modal==="add"){setMenu(p=>[...p,{id:"m"+generateId(),name:form.name.trim(),price,category:form.category,available:true}]);toast.add("Item added!");}
    else{setMenu(p=>p.map(m=>m.id===modal.id?{...m,name:form.name.trim(),price,category:form.category}:m));toast.add("Item updated!");}
    setModal(null);
  };
  const canEdit = user.role==="admin";
  return (
    <div>
      <div className="topbar"><div className="topbar-title">Menu Management</div>{canEdit&&<button className="btn btn-primary" onClick={()=>{setForm({name:"",price:"",category:"breakfast"});setModal("add");}}>+ Add Item</button>}</div>
      <div className="menu-controls"><input className="search-input" placeholder="Search items..." value={search} onChange={e=>setSearch(e.target.value)}/></div>
      <div className="cat-filter">
        {["all",...CATEGORIES].map(c=><button key={c} className={`cat-btn ${catFilter===c?"active":""}`} onClick={()=>setCatFilter(c)}>{c==="all"?"All":`${CATEGORY_ICONS[c]} ${c}`}</button>)}
      </div>
      <div className="menu-grid">
        {filtered.map(item=>(
          <div key={item.id} className={`menu-card ${!item.available?"unavailable":""}`}>
            <div><span className="badge" style={{background:`${CATEGORY_COLORS[item.category]}20`,color:CATEGORY_COLORS[item.category],borderRadius:6}}>{CATEGORY_ICONS[item.category]} {item.category}</span></div>
            <div className="menu-card-name mt-8">{item.name}</div>
            <div className="menu-card-price">{formatCurrency(item.price)}</div>
            {canEdit&&<div className="menu-card-actions">
              <button className="btn btn-secondary btn-sm" onClick={()=>{setForm({...item,price:String(item.price)});setModal(item);}}>Edit</button>
              <label className="toggle" style={{marginLeft:"auto"}}><input type="checkbox" checked={item.available} onChange={()=>setMenu(p=>p.map(m=>m.id===item.id?{...m,available:!m.available}:m))}/><div className="toggle-slider"/></label>
              <button className="btn btn-danger btn-sm" onClick={()=>{setMenu(p=>p.filter(m=>m.id!==item.id));toast.add("Deleted","error");}}>✕</button>
            </div>}
          </div>
        ))}
        {canEdit&&<div className="add-item-btn" onClick={()=>{setForm({name:"",price:"",category:"breakfast"});setModal("add");}}><span style={{fontSize:18}}>+</span> New Item</div>}
      </div>
      {modal&&<div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
        <div className="modal">
          <h2>{modal==="add"?"Add Menu Item":"Edit Menu Item"}</h2>
          <div className="form-group"><label>Item Name</label><input className="form-control" value={form.name} onChange={e=>setForm(p=>({...p,name:e.target.value}))} placeholder="e.g. Masala Dosa"/></div>
          <div className="form-row">
            <div className="form-group"><label>Price (₹)</label><input className="form-control" type="number" value={form.price} onChange={e=>setForm(p=>({...p,price:e.target.value}))} placeholder="0.00"/></div>
            <div className="form-group"><label>Category</label><select className="form-control" value={form.category} onChange={e=>setForm(p=>({...p,category:e.target.value}))}>{CATEGORIES.map(c=><option key={c} value={c}>{c}</option>)}</select></div>
          </div>
          <div className="modal-actions"><button className="btn btn-secondary" onClick={()=>setModal(null)}>Cancel</button><button className="btn btn-primary" onClick={save}>Save</button></div>
        </div>
      </div>}
    </div>
  );
}

function InvoiceView({ bill, onClose }) {
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal invoice-modal">
        <div className="invoice-header"><h2>🏨 HotelBill Pro</h2><p style={{color:"var(--muted)",fontSize:12}}>Tax Invoice</p></div>
        <div className="invoice-meta">
          <span><strong>Bill No:</strong> {bill.billNo}</span><span><strong>Date:</strong> {formatDate(bill.createdAt)}</span>
          <span><strong>Time:</strong> {formatTime(bill.createdAt)}</span><span><strong>Customer:</strong> {bill.customerName}</span>
          <span><strong>Payment:</strong> {bill.paymentMode.toUpperCase()}</span><span><strong>GSTIN:</strong> 33XXXXX1234X1ZX</span>
        </div>
        <table className="invoice-items-table">
          <thead><tr><th>Item</th><th style={{textAlign:"center"}}>Qty</th><th style={{textAlign:"right"}}>Rate</th><th style={{textAlign:"right"}}>Amount</th></tr></thead>
          <tbody>{bill.items.map((it,i)=><tr key={i}><td>{it.name}</td><td style={{textAlign:"center"}}>{it.qty}</td><td style={{textAlign:"right"}}>{formatCurrency(it.price)}</td><td style={{textAlign:"right",fontWeight:600}}>{formatCurrency(it.price*it.qty)}</td></tr>)}</tbody>
        </table>
        <div className="invoice-totals">
          <div className="bill-total-row"><span>Subtotal</span><span>{formatCurrency(bill.subtotal)}</span></div>
          <div className="bill-total-row"><span>GST @ 5%</span><span>{formatCurrency(bill.gst)}</span></div>
          {bill.discount>0&&<div className="bill-total-row" style={{color:"var(--green)"}}><span>Discount</span><span>−{formatCurrency(bill.discount)}</span></div>}
          <div className="bill-total-row grand"><span>Grand Total</span><span className="amt">{formatCurrency(bill.total)}</span></div>
        </div>
        <div style={{marginTop:16,padding:"10px",background:"var(--surface2)",borderRadius:"var(--radius-sm)",fontSize:10,color:"var(--muted)",textAlign:"center"}}>Thank you for dining with us! • Computer generated invoice.</div>
        <div className="modal-actions"><button className="btn btn-secondary" onClick={onClose}>Close</button><button className="btn btn-primary" onClick={()=>window.print()}>🖨️ Print</button></div>
      </div>
    </div>
  );
}

function Billing({ menu, bills, setBills, toast }) {
  const [cart, setCart] = useState({}); const [catFilter, setCatFilter] = useState("all"); const [search, setSearch] = useState("");
  const [customerName, setCustomerName] = useState(""); const [discount, setDiscount] = useState(0); const [payMode, setPayMode] = useState("cash"); const [invoiceBill, setInvoiceBill] = useState(null);
  const filtered = menu.filter(m=>m.available&&(catFilter==="all"||m.category===catFilter)&&m.name.toLowerCase().includes(search.toLowerCase()));
  const cartItems = Object.values(cart);
  const subtotal = cartItems.reduce((s,i)=>s+i.price*i.qty,0);
  const gst = +(subtotal*GST_RATE).toFixed(2);
  const discAmt = Math.min(+discount||0,subtotal);
  const total = subtotal+gst-discAmt;
  const generateBill = () => {
    if(cartItems.length===0) return toast.add("Add items first","error");
    const bill={id:generateId(),billNo:generateBillNo(bills.length+1),createdAt:Date.now(),items:cartItems.map(i=>({id:i.id,name:i.name,price:i.price,qty:i.qty})),subtotal,gst,discount:discAmt,total,customerName:customerName||"Guest",paymentMode:payMode,status:"paid"};
    setBills(p=>[bill,...p]); setInvoiceBill(bill); setCart({}); setCustomerName(""); setDiscount(0); setPayMode("cash");
    toast.add(`Bill ${bill.billNo} generated!`);
  };
  return (
    <div>
      <div className="topbar">
        <div className="topbar-title">New Bill</div>
        <div style={{display:"flex",gap:9}}>
          <button className="btn btn-secondary" onClick={()=>{setCart({});setCustomerName("");setDiscount(0);}}>Clear</button>
          <button className="btn btn-primary" onClick={generateBill}>Generate Bill →</button>
        </div>
      </div>
      <div className="billing-layout">
        <div className="card billing-menu">
          <div style={{marginBottom:12}}>
            <input className="search-input" placeholder="Search menu..." value={search} onChange={e=>setSearch(e.target.value)} style={{width:"100%",marginBottom:10}}/>
            <div className="cat-filter" style={{marginBottom:0}}>{["all",...CATEGORIES].map(c=><button key={c} className={`cat-btn ${catFilter===c?"active":""}`} onClick={()=>setCatFilter(c)}>{c==="all"?"All":`${CATEGORY_ICONS[c]} ${c}`}</button>)}</div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(145px,1fr))",gap:9}}>
            {filtered.map(item=>(
              <div key={item.id} className={`menu-item-select ${cart[item.id]?"in-cart":""}`} onClick={()=>setCart(p=>({...p,[item.id]:{...item,qty:(p[item.id]?.qty||0)+1}}))}>
                <div className="item-n">{item.name}</div>
                <div className="item-p">{formatCurrency(item.price)}</div>
                <div style={{fontSize:10,color:"var(--muted)",marginTop:3}}>{CATEGORY_ICONS[item.category]} {item.category}</div>
                {cart[item.id]&&<div style={{marginTop:5}}><span className="badge badge-success">×{cart[item.id].qty}</span></div>}
              </div>
            ))}
          </div>
        </div>
        <div className="billing-sidebar-panel">
          <div className="card">
            <div className="card-title" style={{marginBottom:14}}>Current Bill</div>
            <div className="form-group"><label>Customer / Table</label><input className="form-control" placeholder="e.g. Table 3" value={customerName} onChange={e=>setCustomerName(e.target.value)}/></div>
            {cartItems.length===0?<div className="empty-state" style={{padding:"20px 10px"}}><div className="icon" style={{fontSize:28}}>🛒</div><p style={{fontSize:11}}>Tap menu items to add</p></div>:
            <div>{cartItems.map(item=>(
              <div key={item.id} className="bill-item-row">
                <div style={{flex:1}}><div className="bill-item-name">{item.name}</div><div className="bill-item-price">{formatCurrency(item.price)}</div></div>
                <div className="qty-control">
                  <button className="qty-btn" onClick={()=>setCart(p=>{const qty=(p[item.id]?.qty||0)-1;if(qty<=0){const n={...p};delete n[item.id];return n;}return{...p,[item.id]:{...p[item.id],qty}}})}>−</button>
                  <span className="qty-display">{item.qty}</span>
                  <button className="qty-btn" onClick={()=>setCart(p=>({...p,[item.id]:{...p[item.id],qty:p[item.id].qty+1}}))}>+</button>
                </div>
                <div style={{minWidth:55,textAlign:"right",fontSize:12,fontWeight:600,color:"var(--accent)"}}>{formatCurrency(item.price*item.qty)}</div>
              </div>
            ))}</div>}
          </div>
          <div className="card">
            <div className="form-group mb-16"><label>Discount (₹)</label><input className="form-control" type="number" value={discount} onChange={e=>setDiscount(e.target.value)} placeholder="0" min="0"/></div>
            <div className="bill-total-row"><span>Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
            <div className="bill-total-row"><span>GST (5%)</span><span>{formatCurrency(gst)}</span></div>
            {discAmt>0&&<div className="bill-total-row text-green"><span>Discount</span><span>−{formatCurrency(discAmt)}</span></div>}
            <div className="bill-total-row grand"><span>Total</span><span className="amt">{formatCurrency(total)}</span></div>
            <div className="section-divider"/>
            <div style={{fontSize:11,color:"var(--muted)",marginBottom:7}}>Payment Mode</div>
            <div className="payment-modes">
              {["cash","upi","card"].map(m=><button key={m} className={`pay-mode ${payMode===m?"active":""}`} onClick={()=>setPayMode(m)}>{m==="cash"?"💵":m==="upi"?"📱":"💳"} {m.toUpperCase()}</button>)}
            </div>
          </div>
        </div>
      </div>
      {invoiceBill&&<InvoiceView bill={invoiceBill} onClose={()=>setInvoiceBill(null)}/>}
    </div>
  );
}

function Transactions({ bills }) {
  const [view, setView] = useState(null); const [search, setSearch] = useState("");
  const filtered = [...bills].filter(b=>b.billNo.toLowerCase().includes(search.toLowerCase())||b.customerName.toLowerCase().includes(search.toLowerCase())).sort((a,b)=>b.createdAt-a.createdAt);
  return (
    <div>
      <div className="topbar"><div className="topbar-title">Transactions</div><span className="badge badge-info">{bills.length} bills</span></div>
      <div className="card">
        <input className="search-input" placeholder="Search bill no or customer..." value={search} onChange={e=>setSearch(e.target.value)} style={{marginBottom:18,width:"100%",maxWidth:360}}/>
        {filtered.length===0?<div className="empty-state"><div className="icon">🧾</div><p>No transactions found</p></div>:
        <div className="table-wrap"><table>
          <thead><tr><th>Bill No</th><th>Customer</th><th>Items</th><th>Total</th><th>Mode</th><th>Date</th><th></th></tr></thead>
          <tbody>{filtered.map(b=>(
            <tr key={b.id}>
              <td className="fw-600 text-accent">{b.billNo}</td>
              <td>{b.customerName}</td>
              <td className="text-muted">{b.items.length} items</td>
              <td className="fw-600">{formatCurrency(b.total)}</td>
              <td><span className="badge badge-info">{b.paymentMode.toUpperCase()}</span></td>
              <td className="text-muted fs-12">{formatDate(b.createdAt)}</td>
              <td><button className="btn btn-secondary btn-sm" onClick={()=>setView(b)}>View</button></td>
            </tr>
          ))}</tbody>
        </table></div>}
      </div>
      {view&&<InvoiceView bill={view} onClose={()=>setView(null)}/>}
    </div>
  );
}

function Reports({ bills }) {
  const [period, setPeriod] = useState("daily");
  const getBills = () => { if(period==="daily") return bills.filter(b=>dayStart(b.createdAt)>=dayStart(Date.now())); if(period==="weekly") return bills.filter(b=>b.createdAt>=weekStart()); return bills.filter(b=>b.createdAt>=monthStart()); };
  const periodBills = getBills();
  const total = periodBills.reduce((s,b)=>s+b.total,0);
  const totalGST = periodBills.reduce((s,b)=>s+b.gst,0);
  const totalDiscount = periodBills.reduce((s,b)=>s+b.discount,0);
  const itemMap = {};
  periodBills.forEach(b=>b.items.forEach(it=>{if(!itemMap[it.name])itemMap[it.name]={qty:0,rev:0};itemMap[it.name].qty+=it.qty;itemMap[it.name].rev+=it.price*it.qty;}));
  const itemReport = Object.entries(itemMap).sort((a,b)=>b[1].rev-a[1].rev);
  const payMap = {cash:0,upi:0,card:0};
  periodBills.forEach(b=>{payMap[b.paymentMode]=(payMap[b.paymentMode]||0)+b.total;});
  const exportCSV = () => {
    const rows=[["Bill No","Customer","Date","Subtotal","GST","Discount","Total","Payment"],...periodBills.map(b=>[b.billNo,b.customerName,formatDate(b.createdAt),b.subtotal,b.gst,b.discount,b.total,b.paymentMode])];
    const csv=rows.map(r=>r.join(",")).join("\n");
    const blob=new Blob([csv],{type:"text/csv"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`report-${period}-${today()}.csv`;a.click();
  };
  return (
    <div>
      <div className="topbar"><div className="topbar-title">Reports</div><button className="btn btn-success" onClick={exportCSV}>⬇ Export CSV</button></div>
      <div className="report-tabs">{["daily","weekly","monthly"].map(p=><button key={p} className={`report-tab ${period===p?"active":""}`} onClick={()=>setPeriod(p)}>{p.charAt(0).toUpperCase()+p.slice(1)}</button>)}</div>
      <div className="stats-grid">
        {[{label:"Revenue",val:formatCurrency(total),color:"var(--accent)",sub:`${periodBills.length} bills`},{label:"GST Collected",val:formatCurrency(totalGST),color:"var(--green)",sub:"@ 5% rate"},{label:"Discounts Given",val:formatCurrency(totalDiscount),color:"var(--red)",sub:"total"},{label:"Avg Bill",val:formatCurrency(periodBills.length?total/periodBills.length:0),color:"var(--blue)",sub:"per transaction"}].map((s,i)=>(
          <div key={i} className="stat-card"><div className="stat-label">{s.label}</div><div className="stat-value" style={{color:s.color,fontSize:20}}>{s.val}</div><div className="stat-sub">{s.sub}</div></div>
        ))}
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title" style={{marginBottom:14}}>Item-wise Revenue</div>
          {itemReport.length===0?<div className="empty-state"><div className="icon">📊</div><p>No data for this period</p></div>:
          <div className="table-wrap"><table>
            <thead><tr><th>Item</th><th>Qty</th><th>Revenue</th></tr></thead>
            <tbody>{itemReport.map(([name,data])=><tr key={name}><td className="fw-600">{name}</td><td><span className="badge badge-info">{data.qty}</span></td><td className="text-accent fw-600">{formatCurrency(data.rev)}</td></tr>)}</tbody>
          </table></div>}
        </div>
        <div className="card">
          <div className="card-title" style={{marginBottom:14}}>Payment Breakdown</div>
          {Object.entries(payMap).map(([mode,amt])=>{const pct=total>0?(amt/total)*100:0;return(
            <div key={mode} style={{marginBottom:16}}>
              <div className="flex-between" style={{marginBottom:6}}><span className="fw-600">{mode.toUpperCase()}</span><span className="text-accent fw-600">{formatCurrency(amt)}</span></div>
              <div style={{background:"var(--surface2)",borderRadius:99,height:7,overflow:"hidden"}}><div style={{background:"var(--accent)",height:"100%",width:`${pct}%`,borderRadius:99}}/></div>
              <div className="fs-12 text-muted" style={{marginTop:3}}>{pct.toFixed(1)}%</div>
            </div>
          );})}
          {total===0&&<div className="empty-state"><div className="icon">💳</div><p>No payments this period</p></div>}
        </div>
      </div>
    </div>
  );
}

function Settings({ user, toast }) {
  const [hotelName, setHotelName] = useState("HotelBill Pro");
  const [address, setAddress] = useState("123 Main Street, Madurai, Tamil Nadu");
  const [phone, setPhone] = useState("+91 98765 43210");
  const [gstin, setGstin] = useState("33XXXXX1234X1ZX");
  return (
    <div>
      <div className="topbar"><div className="topbar-title">Settings</div></div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title" style={{marginBottom:18}}>Hotel Information</div>
          <div className="form-group"><label>Hotel Name</label><input className="form-control" value={hotelName} onChange={e=>setHotelName(e.target.value)}/></div>
          <div className="form-group"><label>Address</label><input className="form-control" value={address} onChange={e=>setAddress(e.target.value)}/></div>
          <div className="form-group"><label>Phone</label><input className="form-control" value={phone} onChange={e=>setPhone(e.target.value)}/></div>
          <div className="form-group"><label>GSTIN</label><input className="form-control" value={gstin} onChange={e=>setGstin(e.target.value)}/></div>
          <button className="btn btn-primary" onClick={()=>toast.add("Settings saved!")}>Save Changes</button>
        </div>
        <div className="card">
          <div className="card-title" style={{marginBottom:18}}>Billing Preferences</div>
          {[{label:"GST @ 5%",sub:"Apply GST on all bills",def:true},{label:"Auto Bill Numbers",sub:"Auto-generate invoice IDs",def:true},{label:"Print on Save",sub:"Auto open print dialog",def:false}].map((s,i)=>(
            <div key={i} className="flex-between" style={{marginBottom:16,padding:"10px 0",borderBottom:"1px solid var(--border)"}}>
              <div><div className="fw-600">{s.label}</div><div className="fs-12 text-muted">{s.sub}</div></div>
              <label className="toggle"><input type="checkbox" defaultChecked={s.def}/><div className="toggle-slider"/></label>
            </div>
          ))}
          <div style={{marginTop:8}}>
            <div className="fs-12 text-muted mb-16">Logged in as</div>
            <div style={{display:"flex",alignItems:"center",gap:10}}><div className="user-avatar">{user.name[0]}</div><div><div className="fw-600">{user.name}</div><div className="fs-12 text-muted">{user.username} · {user.role}</div></div></div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [menu, setMenu] = useState(INITIAL_MENU);
  const [bills, setBills] = useState(generateSeedBills);
  const toast = useToast();
  if(!user) return <><style>{CSS}</style><Login onLogin={setUser}/></>;
  return (
    <>
      <style>{CSS}</style>
      <div className="app-layout">
        <Sidebar page={page} setPage={setPage} user={user} onLogout={()=>{setUser(null);setPage("dashboard");}}/>
        <main className="main-content">
          {page==="dashboard"&&<Dashboard bills={bills} menu={menu}/>}
          {page==="menu"&&<MenuManagement menu={menu} setMenu={setMenu} user={user} toast={toast}/>}
          {page==="billing"&&<Billing menu={menu} bills={bills} setBills={setBills} toast={toast}/>}
          {page==="transactions"&&<Transactions bills={bills}/>}
          {page==="reports"&&<Reports bills={bills}/>}
          {page==="settings"&&<Settings user={user} toast={toast}/>}
        </main>
      </div>
      <Toast toasts={toast.toasts}/>
    </>
  );
}
