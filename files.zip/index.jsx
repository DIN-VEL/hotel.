import { useState, useEffect, useRef, useCallback } from "react";

// ─── Utility Helpers ───────────────────────────────────────────────────────────
const generateId = () => Math.random().toString(36).substr(2, 9).toUpperCase();
const generateBillNo = (count) => `INV-${new Date().getFullYear()}-${String(count).padStart(4, "0")}`;
const formatCurrency = (n) => `₹${Number(n).toFixed(2)}`;
const formatDate = (d) => new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
const formatTime = (d) => new Date(d).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" });
const today = () => new Date().toISOString().split("T")[0];
const dayStart = (d) => { const x = new Date(d); x.setHours(0,0,0,0); return x; };
const weekStart = () => { const d = new Date(); d.setDate(d.getDate() - d.getDay()); d.setHours(0,0,0,0); return d; };
const monthStart = () => { const d = new Date(); d.setDate(1); d.setHours(0,0,0,0); return d; };

// ─── Crypto / Auth ─────────────────────────────────────────────────────────────
const hashPassword = (pw) => btoa(pw + "::hotel_salt_2024");
const verifyPassword = (pw, hash) => hashPassword(pw) === hash;

// ─── Initial Data ──────────────────────────────────────────────────────────────
const INITIAL_USERS = [
  { id: "u1", username: "admin", passwordHash: hashPassword("admin123"), role: "admin", name: "Admin User" },
  { id: "u2", username: "staff", passwordHash: hashPassword("staff123"), role: "staff", name: "Staff Member" },
];

const INITIAL_MENU = [
  { id: "m1", name: "Masala Dosa", price: 80, category: "breakfast", available: true },
  { id: "m2", name: "Idli Sambar (4 pcs)", price: 60, category: "breakfast", available: true },
  { id: "m3", name: "Poori Bhaji", price: 70, category: "breakfast", available: true },
  { id: "m4", name: "Vada (2 pcs)", price: 50, category: "breakfast", available: true },
  { id: "m5", name: "Uthappam", price: 90, category: "breakfast", available: true },
  { id: "m6", name: "Veg Thali", price: 180, category: "lunch", available: true },
  { id: "m7", name: "Non-Veg Thali", price: 250, category: "lunch", available: true },
  { id: "m8", name: "Chicken Biryani", price: 220, category: "lunch", available: true },
  { id: "m9", name: "Paneer Butter Masala", price: 160, category: "lunch", available: true },
  { id: "m10", name: "Dal Fry + Rice", price: 120, category: "lunch", available: true },
  { id: "m11", name: "Mutton Curry", price: 280, category: "dinner", available: true },
  { id: "m12", name: "Tandoori Chicken (half)", price: 300, category: "dinner", available: true },
  { id: "m13", name: "Naan", price: 40, category: "dinner", available: true },
  { id: "m14", name: "Palak Paneer", price: 170, category: "dinner", available: true },
  { id: "m15", name: "Fish Curry", price: 240, category: "dinner", available: true },
  { id: "m16", name: "Filter Coffee", price: 30, category: "beverages", available: true },
  { id: "m17", name: "Masala Chai", price: 25, category: "beverages", available: true },
  { id: "m18", name: "Fresh Lime Soda", price: 50, category: "beverages", available: true },
  { id: "m19", name: "Mango Lassi", price: 80, category: "beverages", available: true },
  { id: "m20", name: "Mineral Water", price: 20, category: "beverages", available: true },
];

// Generate seed bills for demo
const generateSeedBills = () => {
  const bills = [];
  const now = Date.now();
  const items = [
    [{ id: "m1", name: "Masala Dosa", price: 80, qty: 2 }, { id: "m16", name: "Filter Coffee", price: 30, qty: 2 }],
    [{ id: "m6", name: "Veg Thali", price: 180, qty: 3 }],
    [{ id: "m8", name: "Chicken Biryani", price: 220, qty: 2 }, { id: "m18", name: "Fresh Lime Soda", price: 50, qty: 2 }],
    [{ id: "m12", name: "Tandoori Chicken (half)", price: 300, qty: 1 }, { id: "m13", name: "Naan", price: 40, qty: 4 }],
    [{ id: "m2", name: "Idli Sambar (4 pcs)", price: 60, qty: 4 }, { id: "m17", name: "Masala Chai", price: 25, qty: 4 }],
    [{ id: "m7", name: "Non-Veg Thali", price: 250, qty: 2 }, { id: "m19", name: "Mango Lassi", price: 80, qty: 2 }],
    [{ id: "m11", name: "Mutton Curry", price: 280, qty: 1 }, { id: "m13", name: "Naan", price: 40, qty: 3 }],
    [{ id: "m9", name: "Paneer Butter Masala", price: 160, qty: 2 }, { id: "m10", name: "Dal Fry + Rice", price: 120, qty: 2 }],
  ];
  const offsets = [2*3600000, 5*3600000, 8*3600000, 14*3600000, 26*3600000, 48*3600000, 72*3600000, 120*3600000];
  offsets.forEach((offset, i) => {
    const billItems = items[i];
    const subtotal = billItems.reduce((s, it) => s + it.price * it.qty, 0);
    const gst = +(subtotal * 0.05).toFixed(2);
    const total = subtotal + gst;
    bills.push({ id: generateId(), billNo: generateBillNo(i + 1), createdAt: now - offset, items: billItems, subtotal, gst, discount: 0, total, customerName: ["Table 1","Table 2","Table 3","Table 4","Table 5","Table 6","Table 7","Table 8"][i], paymentMode: ["cash","upi","card"][i % 3], status: "paid" });
  });
  return bills;
};

const CATEGORIES = ["breakfast", "lunch", "dinner", "beverages"];
const CATEGORY_COLORS = { breakfast: "#f59e0b", lunch: "#10b981", dinner: "#6366f1", beverages: "#3b82f6" };
const CATEGORY_ICONS = { breakfast: "☀️", lunch: "🍱", dinner: "🌙", beverages: "☕" };
const GST_RATE = 0.05;

// ─── CSS ───────────────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg: #0f0f12;
  --surface: #18181f;
  --surface2: #22222c;
  --surface3: #2a2a38;
  --border: rgba(255,255,255,0.07);
  --border2: rgba(255,255,255,0.12);
  --text: #f0eff5;
  --muted: #8885a0;
  --accent: #e8b86d;
  --accent2: #c9965a;
  --green: #4ade80;
  --red: #f87171;
  --blue: #60a5fa;
  --purple: #a78bfa;
  --sidebar-w: 240px;
  --radius: 12px;
  --radius-sm: 8px;
  font-size: 14px;
}

body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; min-height: 100vh; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 4px; height: 4px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--surface3); border-radius: 99px; }

/* ── Login ── */
.login-wrap { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: var(--bg); position: relative; overflow: hidden; }
.login-bg { position: absolute; inset: 0; background: radial-gradient(ellipse 60% 50% at 50% 0%, rgba(232,184,109,0.08) 0%, transparent 70%); pointer-events: none; }
.login-grid { position: absolute; inset: 0; background-image: linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px); background-size: 40px 40px; pointer-events: none; }
.login-card { width: 420px; background: var(--surface); border: 1px solid var(--border2); border-radius: 20px; padding: 48px; position: relative; z-index: 1; }
.login-logo { text-align: center; margin-bottom: 32px; }
.login-logo h1 { font-family: 'DM Serif Display', serif; font-size: 28px; color: var(--accent); letter-spacing: -0.5px; }
.login-logo p { color: var(--muted); font-size: 13px; margin-top: 4px; }
.form-group { margin-bottom: 20px; }
.form-group label { display: block; font-size: 12px; font-weight: 600; letter-spacing: 0.5px; text-transform: uppercase; color: var(--muted); margin-bottom: 8px; }
.form-control { width: 100%; background: var(--surface2); border: 1px solid var(--border2); border-radius: var(--radius-sm); padding: 12px 14px; color: var(--text); font-size: 14px; font-family: inherit; transition: border-color 0.2s; outline: none; }
.form-control:focus { border-color: var(--accent); }
.form-control::placeholder { color: var(--muted); }
.btn { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 12px 20px; border-radius: var(--radius-sm); border: none; cursor: pointer; font-size: 14px; font-weight: 600; font-family: inherit; transition: all 0.2s; }
.btn-primary { background: var(--accent); color: #1a1208; }
.btn-primary:hover { background: var(--accent2); transform: translateY(-1px); }
.btn-secondary { background: var(--surface2); color: var(--text); border: 1px solid var(--border2); }
.btn-secondary:hover { background: var(--surface3); }
.btn-danger { background: rgba(248,113,113,0.15); color: var(--red); border: 1px solid rgba(248,113,113,0.3); }
.btn-danger:hover { background: rgba(248,113,113,0.25); }
.btn-success { background: rgba(74,222,128,0.15); color: var(--green); border: 1px solid rgba(74,222,128,0.3); }
.btn-success:hover { background: rgba(74,222,128,0.25); }
.btn-sm { padding: 7px 14px; font-size: 12px; }
.btn-full { width: 100%; }
.login-creds { margin-top: 20px; background: var(--surface2); border-radius: var(--radius-sm); padding: 14px; font-size: 12px; color: var(--muted); line-height: 1.8; }
.login-creds strong { color: var(--text); }
.error-msg { background: rgba(248,113,113,0.1); border: 1px solid rgba(248,113,113,0.3); color: var(--red); border-radius: var(--radius-sm); padding: 10px 14px; font-size: 13px; margin-bottom: 16px; }

/* ── Layout ── */
.app-layout { display: flex; min-height: 100vh; }

/* ── Sidebar ── */
.sidebar { width: var(--sidebar-w); background: var(--surface); border-right: 1px solid var(--border); display: flex; flex-direction: column; position: fixed; top: 0; left: 0; height: 100vh; z-index: 100; }
.sidebar-brand { padding: 24px 20px 20px; border-bottom: 1px solid var(--border); }
.sidebar-brand h2 { font-family: 'DM Serif Display', serif; font-size: 20px; color: var(--accent); }
.sidebar-brand p { font-size: 11px; color: var(--muted); margin-top: 2px; }
.sidebar-nav { flex: 1; padding: 16px 12px; display: flex; flex-direction: column; gap: 2px; overflow-y: auto; }
.nav-item { display: flex; align-items: center; gap: 12px; padding: 10px 12px; border-radius: var(--radius-sm); cursor: pointer; font-size: 13.5px; font-weight: 500; color: var(--muted); transition: all 0.15s; }
.nav-item:hover { background: var(--surface2); color: var(--text); }
.nav-item.active { background: rgba(232,184,109,0.12); color: var(--accent); }
.nav-item .nav-icon { font-size: 16px; width: 20px; text-align: center; }
.nav-badge { margin-left: auto; background: var(--accent); color: #1a1208; font-size: 10px; font-weight: 700; padding: 2px 7px; border-radius: 99px; }
.sidebar-footer { padding: 16px 12px; border-top: 1px solid var(--border); }
.user-info { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
.user-avatar { width: 36px; height: 36px; border-radius: 50%; background: linear-gradient(135deg, var(--accent), var(--accent2)); display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; color: #1a1208; flex-shrink: 0; }
.user-name { font-size: 13px; font-weight: 600; }
.user-role { font-size: 11px; color: var(--muted); text-transform: capitalize; }

/* ── Main Content ── */
.main-content { margin-left: var(--sidebar-w); flex: 1; padding: 32px; min-height: 100vh; }
.page-header { margin-bottom: 28px; }
.page-header h1 { font-family: 'DM Serif Display', serif; font-size: 26px; letter-spacing: -0.3px; }
.page-header p { color: var(--muted); margin-top: 4px; font-size: 13px; }

/* ── Stats Cards ── */
.stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
.stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; }
.stat-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); margin-bottom: 8px; }
.stat-value { font-size: 26px; font-weight: 700; font-family: 'DM Serif Display', serif; letter-spacing: -1px; }
.stat-sub { font-size: 12px; color: var(--muted); margin-top: 4px; }
.stat-icon { font-size: 28px; float: right; margin-top: -4px; opacity: 0.8; }

/* ── Grid Layouts ── */
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
.grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.full-width { grid-column: 1 / -1; }

/* ── Cards ── */
.card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius); padding: 24px; }
.card-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
.card-title { font-weight: 600; font-size: 15px; }
.card-subtitle { font-size: 12px; color: var(--muted); margin-top: 2px; }

/* ── Bar Chart ── */
.bar-chart { display: flex; align-items: flex-end; gap: 8px; height: 120px; }
.bar-col { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 6px; height: 100%; justify-content: flex-end; }
.bar { width: 100%; border-radius: 6px 6px 0 0; background: var(--accent); opacity: 0.85; min-height: 4px; transition: opacity 0.2s; }
.bar:hover { opacity: 1; }
.bar-label { font-size: 10px; color: var(--muted); }
.bar-val { font-size: 9px; color: var(--accent); font-weight: 600; }

/* ── Tables ── */
.table-wrap { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; }
th { text-align: left; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: var(--muted); padding: 10px 14px; border-bottom: 1px solid var(--border); }
td { padding: 12px 14px; border-bottom: 1px solid var(--border); font-size: 13.5px; vertical-align: middle; }
tr:last-child td { border-bottom: none; }
tr:hover td { background: rgba(255,255,255,0.02); }

/* ── Badges ── */
.badge { display: inline-flex; align-items: center; padding: 3px 10px; border-radius: 99px; font-size: 11px; font-weight: 600; }
.badge-success { background: rgba(74,222,128,0.12); color: var(--green); }
.badge-warning { background: rgba(245,158,11,0.12); color: #fbbf24; }
.badge-info { background: rgba(96,165,250,0.12); color: var(--blue); }
.badge-purple { background: rgba(167,139,250,0.12); color: var(--purple); }
.badge-cat { border-radius: var(--radius-sm); }

/* ── Menu Management ── */
.menu-controls { display: flex; gap: 12px; margin-bottom: 20px; align-items: center; }
.search-input { flex: 1; background: var(--surface2); border: 1px solid var(--border2); border-radius: var(--radius-sm); padding: 10px 14px; color: var(--text); font-size: 13px; font-family: inherit; outline: none; }
.search-input:focus { border-color: var(--accent); }
.cat-filter { display: flex; gap: 8px; flex-wrap: wrap; }
.cat-btn { padding: 6px 14px; border-radius: 99px; border: 1px solid var(--border2); background: transparent; color: var(--muted); font-size: 12px; font-weight: 500; cursor: pointer; transition: all 0.15s; font-family: inherit; }
.cat-btn.active { background: var(--accent); color: #1a1208; border-color: var(--accent); }
.menu-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 14px; }
.menu-card { background: var(--surface2); border: 1px solid var(--border); border-radius: var(--radius); padding: 16px; position: relative; transition: border-color 0.2s; }
.menu-card:hover { border-color: var(--border2); }
.menu-card.unavailable { opacity: 0.5; }
.menu-card-name { font-weight: 600; font-size: 14px; margin-bottom: 6px; }
.menu-card-price { font-size: 20px; font-weight: 700; color: var(--accent); font-family: 'DM Serif Display', serif; }
.menu-card-cat { font-size: 11px; margin-top: 6px; }
.menu-card-actions { display: flex; gap: 6px; margin-top: 12px; }
.add-item-btn { width: 100%; background: rgba(232,184,109,0.08); border: 1px dashed rgba(232,184,109,0.3); border-radius: var(--radius); padding: 24px; cursor: pointer; color: var(--accent); font-size: 13px; font-weight: 500; font-family: inherit; display: flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.2s; grid-column: span 1; }
.add-item-btn:hover { background: rgba(232,184,109,0.12); }

/* ── Modal ── */
.modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(4px); z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 20px; }
.modal { background: var(--surface); border: 1px solid var(--border2); border-radius: 16px; padding: 32px; width: 480px; max-width: 100%; max-height: 90vh; overflow-y: auto; }
.modal h2 { font-family: 'DM Serif Display', serif; font-size: 22px; margin-bottom: 24px; }
.modal-actions { display: flex; gap: 10px; margin-top: 24px; justify-content: flex-end; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
select.form-control option { background: var(--surface); }

/* ── Billing ── */
.billing-layout { display: grid; grid-template-columns: 1fr 380px; gap: 20px; height: calc(100vh - 140px); }
.billing-menu { overflow-y: auto; }
.billing-sidebar-panel { display: flex; flex-direction: column; gap: 16px; overflow-y: auto; }
.bill-item-row { display: flex; align-items: center; gap: 10px; padding: 10px 0; border-bottom: 1px solid var(--border); }
.bill-item-name { flex: 1; font-size: 13px; font-weight: 500; }
.bill-item-price { font-size: 12px; color: var(--muted); }
.qty-control { display: flex; align-items: center; gap: 8px; }
.qty-btn { width: 26px; height: 26px; border-radius: 50%; border: 1px solid var(--border2); background: var(--surface2); color: var(--text); cursor: pointer; font-size: 16px; display: flex; align-items: center; justify-content: center; line-height: 1; }
.qty-btn:hover { border-color: var(--accent); color: var(--accent); }
.qty-display { font-size: 14px; font-weight: 600; min-width: 20px; text-align: center; }
.bill-total-row { display: flex; justify-content: space-between; font-size: 13px; padding: 5px 0; color: var(--muted); }
.bill-total-row.grand { font-size: 16px; font-weight: 700; color: var(--text); padding-top: 12px; border-top: 1px solid var(--border); margin-top: 6px; }
.bill-total-row.grand .amt { color: var(--accent); }
.menu-item-select { cursor: pointer; border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 12px; background: var(--surface2); transition: all 0.15s; }
.menu-item-select:hover { border-color: var(--accent); }
.menu-item-select.in-cart { border-color: var(--accent); background: rgba(232,184,109,0.06); }
.menu-item-select .item-n { font-weight: 500; font-size: 13px; }
.menu-item-select .item-p { font-size: 16px; font-weight: 700; color: var(--accent); font-family: 'DM Serif Display', serif; }
.payment-modes { display: flex; gap: 8px; }
.pay-mode { flex: 1; padding: 10px; border-radius: var(--radius-sm); border: 1px solid var(--border2); background: var(--surface2); cursor: pointer; text-align: center; font-size: 12px; font-weight: 500; font-family: inherit; color: var(--muted); transition: all 0.15s; }
.pay-mode.active { border-color: var(--accent); color: var(--accent); background: rgba(232,184,109,0.08); }

/* ── Invoice Print ── */
.invoice-modal { width: 580px; }
.invoice-header { text-align: center; margin-bottom: 24px; padding-bottom: 20px; border-bottom: 2px solid var(--border); }
.invoice-header h2 { font-family: 'DM Serif Display', serif; font-size: 30px; color: var(--accent); }
.invoice-meta { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 20px; font-size: 12px; color: var(--muted); }
.invoice-meta span strong { color: var(--text); }
.invoice-items-table { width: 100%; margin-bottom: 16px; font-size: 13px; }
.invoice-totals { border-top: 1px solid var(--border); padding-top: 12px; font-size: 13px; }
@media print { .modal-overlay { position: static; background: white; padding: 0; } .modal { border: none; width: 100%; box-shadow: none; color: black; } .no-print { display: none !important; } }

/* ── Reports ── */
.report-tabs { display: flex; gap: 4px; background: var(--surface2); border-radius: var(--radius-sm); padding: 4px; margin-bottom: 24px; width: fit-content; }
.report-tab { padding: 8px 20px; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 500; color: var(--muted); transition: all 0.15s; border: none; background: transparent; font-family: inherit; }
.report-tab.active { background: var(--accent); color: #1a1208; }
.donut-wrap { display: flex; align-items: center; gap: 24px; }
.legend-item { display: flex; align-items: center; gap: 8px; font-size: 12px; margin-bottom: 8px; }
.legend-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }

/* ── Topbar ── */
.topbar { display: flex; align-items: center; justify-content: space-between; margin-bottom: 28px; }
.topbar-title { font-family: 'DM Serif Display', serif; font-size: 26px; }
.topbar-right { display: flex; align-items: center; gap: 12px; }
.time-badge { font-size: 12px; color: var(--muted); background: var(--surface); border: 1px solid var(--border); border-radius: 99px; padding: 6px 14px; }

/* ── Toggle ── */
.toggle { position: relative; width: 40px; height: 22px; }
.toggle input { opacity: 0; width: 0; height: 0; }
.toggle-slider { position: absolute; inset: 0; background: var(--surface3); border-radius: 99px; cursor: pointer; transition: 0.2s; }
.toggle-slider::before { content: ''; position: absolute; width: 16px; height: 16px; left: 3px; top: 3px; background: var(--muted); border-radius: 50%; transition: 0.2s; }
.toggle input:checked + .toggle-slider { background: rgba(74,222,128,0.2); }
.toggle input:checked + .toggle-slider::before { transform: translateX(18px); background: var(--green); }

/* ── Sparkline ── */
.sparkline { display: flex; align-items: flex-end; gap: 3px; height: 40px; }
.spark-bar { flex: 1; border-radius: 3px 3px 0 0; background: rgba(232,184,109,0.35); min-height: 2px; }

/* ── Empty state ── */
.empty-state { text-align: center; padding: 48px 20px; color: var(--muted); }
.empty-state .icon { font-size: 48px; margin-bottom: 12px; }
.empty-state p { font-size: 14px; }

/* ── Toast ── */
.toast-container { position: fixed; bottom: 24px; right: 24px; z-index: 9999; display: flex; flex-direction: column; gap: 8px; }
.toast { background: var(--surface2); border: 1px solid var(--border2); border-radius: var(--radius-sm); padding: 14px 18px; font-size: 13px; display: flex; align-items: center; gap: 10px; animation: slideIn 0.3s ease; min-width: 260px; }
.toast.success { border-color: rgba(74,222,128,0.3); }
.toast.error { border-color: rgba(248,113,113,0.3); }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

/* ── Misc ── */
.section-divider { height: 1px; background: var(--border); margin: 20px 0; }
.text-accent { color: var(--accent); }
.text-muted { color: var(--muted); }
.text-green { color: var(--green); }
.text-red { color: var(--red); }
.flex { display: flex; align-items: center; }
.flex-between { display: flex; align-items: center; justify-content: space-between; }
.gap-8 { gap: 8px; }
.gap-12 { gap: 12px; }
.mt-8 { margin-top: 8px; }
.mt-16 { margin-top: 16px; }
.mb-16 { margin-bottom: 16px; }
.fw-600 { font-weight: 600; }
.fs-12 { font-size: 12px; }
.fs-13 { font-size: 13px; }
`;

// ─── Components ────────────────────────────────────────────────────────────────

function Toast({ toasts, removeToast }) {
  return (
    <div className="toast-container">
      {toasts.map(t => (
        <div key={t.id} className={`toast ${t.type}`} onClick={() => removeToast(t.id)}>
          <span>{t.type === "success" ? "✓" : "✗"}</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

function useToast() {
  const [toasts, setToasts] = useState([]);
  const add = useCallback((msg, type = "success") => {
    const id = Date.now();
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3000);
  }, []);
  const remove = useCallback((id) => setToasts(p => p.filter(t => t.id !== id)), []);
  return { toasts, add, remove };
}

// ─── Login ─────────────────────────────────────────────────────────────────────
function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [users] = useState(INITIAL_USERS);

  const handleSubmit = () => {
    const user = users.find(u => u.username === username);
    if (!user || !verifyPassword(password, user.passwordHash)) {
      setError("Invalid username or password.");
      return;
    }
    onLogin(user);
  };

  return (
    <div className="login-wrap">
      <div className="login-bg" />
      <div className="login-grid" />
      <div className="login-card">
        <div className="login-logo">
          <h1>🏨 HotelBill Pro</h1>
          <p>Hotel Billing Management System</p>
        </div>
        {error && <div className="error-msg">{error}</div>}
        <div className="form-group">
          <label>Username</label>
          <input className="form-control" value={username} onChange={e => setUsername(e.target.value)} placeholder="Enter username" onKeyDown={e => e.key === "Enter" && handleSubmit()} />
        </div>
        <div className="form-group">
          <label>Password</label>
          <input className="form-control" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter password" onKeyDown={e => e.key === "Enter" && handleSubmit()} />
        </div>
        <button className="btn btn-primary btn-full" onClick={handleSubmit}>Sign In →</button>
        <div className="login-creds">
          <div><strong>Admin:</strong> admin / admin123</div>
          <div><strong>Staff:</strong> staff / staff123</div>
        </div>
      </div>
    </div>
  );
}

// ─── Sidebar ───────────────────────────────────────────────────────────────────
const NAV = [
  { id: "dashboard", icon: "◈", label: "Dashboard" },
  { id: "menu", icon: "📋", label: "Menu Management" },
  { id: "billing", icon: "🧾", label: "New Bill" },
  { id: "transactions", icon: "💳", label: "Transactions" },
  { id: "reports", icon: "📊", label: "Reports" },
  { id: "settings", icon: "⚙", label: "Settings" },
];

function Sidebar({ page, setPage, user, onLogout, billCount }) {
  return (
    <div className="sidebar">
      <div className="sidebar-brand">
        <h2>🏨 HotelBill</h2>
        <p>Management System</p>
      </div>
      <nav className="sidebar-nav">
        {NAV.map(n => (
          <div key={n.id} className={`nav-item ${page === n.id ? "active" : ""}`} onClick={() => setPage(n.id)}>
            <span className="nav-icon">{n.icon}</span>
            {n.label}
            {n.id === "billing" && billCount > 0 && <span className="nav-badge">{billCount}</span>}
          </div>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="user-info">
          <div className="user-avatar">{user.name[0]}</div>
          <div>
            <div className="user-name">{user.name}</div>
            <div className="user-role">{user.role}</div>
          </div>
        </div>
        <button className="btn btn-secondary btn-sm btn-full" onClick={onLogout}>Logout</button>
      </div>
    </div>
  );
}

// ─── Dashboard ─────────────────────────────────────────────────────────────────
function Dashboard({ bills, menu }) {
  const [clock, setClock] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setClock(new Date()), 1000); return () => clearInterval(t); }, []);

  const now = Date.now();
  const todayBills = bills.filter(b => dayStart(b.createdAt) >= dayStart(now));
  const weekBills = bills.filter(b => b.createdAt >= weekStart());
  const monthBills = bills.filter(b => b.createdAt >= monthStart());
  const sum = arr => arr.reduce((s, b) => s + b.total, 0);

  // Category breakdown
  const catSales = {};
  bills.forEach(b => b.items.forEach(it => {
    const m = menu.find(x => x.id === it.id);
    const cat = m?.category || "other";
    catSales[cat] = (catSales[cat] || 0) + it.price * it.qty;
  }));

  // Popular items
  const itemCounts = {};
  bills.forEach(b => b.items.forEach(it => { itemCounts[it.name] = (itemCounts[it.name] || 0) + it.qty; }));
  const popular = Object.entries(itemCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);

  // Daily chart (last 7 days)
  const days7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - i)); d.setHours(0, 0, 0, 0);
    const next = new Date(d); next.setDate(next.getDate() + 1);
    const dayBills = bills.filter(b => b.createdAt >= d.getTime() && b.createdAt < next.getTime());
    return { label: d.toLocaleDateString("en-IN", { weekday: "short" }), val: sum(dayBills) };
  });
  const maxDay = Math.max(...days7.map(d => d.val), 1);

  // Total category for donut
  const totalCatSales = Object.values(catSales).reduce((a, b) => a + b, 0) || 1;
  const catColors = { breakfast: "#f59e0b", lunch: "#10b981", dinner: "#6366f1", beverages: "#3b82f6" };

  return (
    <div>
      <div className="topbar">
        <div className="topbar-title">Dashboard</div>
        <div className="topbar-right">
          <div className="time-badge">
            {clock.toLocaleDateString("en-IN", { weekday: "short", day: "2-digit", month: "short" })} · {clock.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
          </div>
        </div>
      </div>

      <div className="stats-grid">
        {[
          { label: "Today's Sales", val: sum(todayBills), icon: "☀️", sub: `${todayBills.length} bills`, color: "#f59e0b" },
          { label: "Weekly Sales", val: sum(weekBills), icon: "📅", sub: `${weekBills.length} bills`, color: "#10b981" },
          { label: "Monthly Sales", val: sum(monthBills), icon: "📆", sub: `${monthBills.length} bills`, color: "#6366f1" },
          { label: "Menu Items", val: menu.filter(m => m.available).length, icon: "🍽️", sub: `${menu.length} total`, color: "#3b82f6", raw: true },
        ].map((s, i) => (
          <div key={i} className="stat-card">
            <div className="stat-icon">{s.icon}</div>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value" style={{ color: s.color }}>{s.raw ? s.val : formatCurrency(s.val)}</div>
            <div className="stat-sub">{s.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-header"><div><div className="card-title">Weekly Revenue</div><div className="card-subtitle">Last 7 days</div></div></div>
          <div className="bar-chart">
            {days7.map((d, i) => (
              <div key={i} className="bar-col">
                <div className="bar-val">{d.val > 0 ? `₹${Math.round(d.val / 1000)}k` : ""}</div>
                <div className="bar" style={{ height: `${Math.max((d.val / maxDay) * 90, 4)}%`, background: i === 6 ? "var(--accent)" : "rgba(232,184,109,0.4)" }} title={formatCurrency(d.val)} />
                <div className="bar-label">{d.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-header"><div><div className="card-title">Sales by Category</div><div className="card-subtitle">All time</div></div></div>
          <div className="donut-wrap">
            <svg width="120" height="120" viewBox="0 0 120 120">
              {(() => {
                let offset = 0;
                return Object.entries(catSales).map(([cat, val]) => {
                  const pct = val / totalCatSales;
                  const dashArray = `${pct * 283} ${283 - pct * 283}`;
                  const el = <circle key={cat} cx="60" cy="60" r="45" fill="none" stroke={catColors[cat] || "#999"} strokeWidth="20" strokeDasharray={dashArray} strokeDashoffset={-offset * 2.83} style={{ transform: "rotate(-90deg)", transformOrigin: "60px 60px" }} />;
                  offset += pct * 100;
                  return el;
                });
              })()}
              <circle cx="60" cy="60" r="30" fill="var(--surface)" />
              <text x="60" y="65" textAnchor="middle" fill="var(--accent)" fontSize="14" fontWeight="700" fontFamily="DM Serif Display">₹</text>
            </svg>
            <div>
              {Object.entries(catSales).map(([cat, val]) => (
                <div key={cat} className="legend-item">
                  <div className="legend-dot" style={{ background: catColors[cat] }} />
                  <span className="text-muted">{cat}</span>
                  <span className="fw-600" style={{ marginLeft: 8 }}>{formatCurrency(val)}</span>
                </div>
              ))}
              {Object.keys(catSales).length === 0 && <div className="text-muted fs-12">No sales data yet</div>}
            </div>
          </div>
        </div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-header"><div className="card-title">Popular Items</div></div>
          {popular.length === 0 ? <div className="empty-state"><div className="icon">🍽️</div><p>No sales yet</p></div> :
            <table><thead><tr><th>#</th><th>Item</th><th>Qty Sold</th></tr></thead>
              <tbody>{popular.map(([name, qty], i) => (
                <tr key={i}><td className="text-muted">{i + 1}</td><td className="fw-600">{name}</td><td><span className="badge badge-success">{qty}</span></td></tr>
              ))}</tbody>
            </table>}
        </div>

        <div className="card">
          <div className="card-header"><div className="card-title">Recent Transactions</div></div>
          {bills.length === 0 ? <div className="empty-state"><div className="icon">🧾</div><p>No bills yet</p></div> :
            <div className="table-wrap">
              <table><thead><tr><th>Bill</th><th>Amount</th><th>Time</th></tr></thead>
                <tbody>{[...bills].sort((a, b) => b.createdAt - a.createdAt).slice(0, 6).map(b => (
                  <tr key={b.id}>
                    <td><div className="fw-600">{b.billNo}</div><div className="fs-12 text-muted">{b.customerName}</div></td>
                    <td className="text-accent fw-600">{formatCurrency(b.total)}</td>
                    <td className="text-muted fs-12">{formatTime(b.createdAt)}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>}
        </div>
      </div>
    </div>
  );
}

// ─── Menu Management ───────────────────────────────────────────────────────────
function MenuManagement({ menu, setMenu, user, toast }) {
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("all");
  const [modal, setModal] = useState(null); // null | "add" | item
  const [form, setForm] = useState({ name: "", price: "", category: "breakfast" });

  const filtered = menu.filter(m =>
    (catFilter === "all" || m.category === catFilter) &&
    m.name.toLowerCase().includes(search.toLowerCase())
  );

  const openAdd = () => { setForm({ name: "", price: "", category: "breakfast" }); setModal("add"); };
  const openEdit = (item) => { setForm({ ...item, price: String(item.price) }); setModal(item); };

  const save = () => {
    if (!form.name.trim() || !form.price) return toast.add("Fill all fields", "error");
    const price = parseFloat(form.price);
    if (isNaN(price) || price <= 0) return toast.add("Invalid price", "error");
    if (modal === "add") {
      setMenu(p => [...p, { id: "m" + generateId(), name: form.name.trim(), price, category: form.category, available: true }]);
      toast.add("Menu item added!");
    } else {
      setMenu(p => p.map(m => m.id === modal.id ? { ...m, name: form.name.trim(), price, category: form.category } : m));
      toast.add("Menu item updated!");
    }
    setModal(null);
  };

  const del = (id) => { setMenu(p => p.filter(m => m.id !== id)); toast.add("Item deleted", "error"); };
  const toggle = (id) => { setMenu(p => p.map(m => m.id === id ? { ...m, available: !m.available } : m)); };

  const canEdit = user.role === "admin";

  return (
    <div>
      <div className="topbar">
        <div><div className="topbar-title">Menu Management</div></div>
        {canEdit && <button className="btn btn-primary" onClick={openAdd}>+ Add Item</button>}
      </div>
      <div className="menu-controls">
        <input className="search-input" placeholder="Search items..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>
      <div className="cat-filter mb-16">
        {["all", ...CATEGORIES].map(c => (
          <button key={c} className={`cat-btn ${catFilter === c ? "active" : ""}`} onClick={() => setCatFilter(c)}>
            {c === "all" ? "All" : `${CATEGORY_ICONS[c]} ${c}`}
          </button>
        ))}
      </div>

      <div className="menu-grid">
        {filtered.map(item => (
          <div key={item.id} className={`menu-card ${!item.available ? "unavailable" : ""}`}>
            <div className="menu-card-cat">
              <span className="badge" style={{ background: `${CATEGORY_COLORS[item.category]}20`, color: CATEGORY_COLORS[item.category] }}>
                {CATEGORY_ICONS[item.category]} {item.category}
              </span>
            </div>
            <div className="menu-card-name mt-8">{item.name}</div>
            <div className="menu-card-price">{formatCurrency(item.price)}</div>
            {canEdit && (
              <div className="menu-card-actions">
                <button className="btn btn-secondary btn-sm" onClick={() => openEdit(item)}>Edit</button>
                <label className="toggle" style={{ marginLeft: "auto" }}>
                  <input type="checkbox" checked={item.available} onChange={() => toggle(item.id)} />
                  <div className="toggle-slider" />
                </label>
                <button className="btn btn-danger btn-sm" onClick={() => del(item.id)}>✕</button>
              </div>
            )}
          </div>
        ))}
        {canEdit && (
          <div className="add-item-btn" onClick={openAdd}>
            <span style={{ fontSize: 20 }}>+</span> New Item
          </div>
        )}
      </div>

      {modal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setModal(null)}>
          <div className="modal">
            <h2>{modal === "add" ? "Add Menu Item" : "Edit Menu Item"}</h2>
            <div className="form-group"><label>Item Name</label><input className="form-control" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Masala Dosa" /></div>
            <div className="form-row">
              <div className="form-group"><label>Price (₹)</label><input className="form-control" type="number" value={form.price} onChange={e => setForm(p => ({ ...p, price: e.target.value }))} placeholder="0.00" /></div>
              <div className="form-group"><label>Category</label>
                <select className="form-control" value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}>
                  {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => setModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={save}>Save Item</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Billing ───────────────────────────────────────────────────────────────────
function Billing({ menu, bills, setBills, toast }) {
  const [cart, setCart] = useState({});
  const [catFilter, setCatFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [discount, setDiscount] = useState(0);
  const [payMode, setPayMode] = useState("cash");
  const [invoiceBill, setInvoiceBill] = useState(null);

  const availMenu = menu.filter(m => m.available);
  const filtered = availMenu.filter(m =>
    (catFilter === "all" || m.category === catFilter) &&
    m.name.toLowerCase().includes(search.toLowerCase())
  );

  const addToCart = (item) => setCart(p => ({ ...p, [item.id]: { ...item, qty: (p[item.id]?.qty || 0) + 1 } }));
  const updateQty = (id, delta) => setCart(p => {
    const qty = (p[id]?.qty || 0) + delta;
    if (qty <= 0) { const n = { ...p }; delete n[id]; return n; }
    return { ...p, [id]: { ...p[id], qty } };
  });

  const cartItems = Object.values(cart);
  const subtotal = cartItems.reduce((s, i) => s + i.price * i.qty, 0);
  const gst = +(subtotal * GST_RATE).toFixed(2);
  const discAmt = Math.min(+discount || 0, subtotal);
  const total = subtotal + gst - discAmt;

  const clearBill = () => { setCart({}); setCustomerName(""); setDiscount(0); setPayMode("cash"); };

  const generateBill = () => {
    if (cartItems.length === 0) return toast.add("Add items to bill", "error");
    const bill = {
      id: generateId(), billNo: generateBillNo(bills.length + 1), createdAt: Date.now(),
      items: cartItems.map(i => ({ id: i.id, name: i.name, price: i.price, qty: i.qty })),
      subtotal, gst, discount: discAmt, total, customerName: customerName || "Guest",
      paymentMode: payMode, status: "paid"
    };
    setBills(p => [bill, ...p]);
    setInvoiceBill(bill);
    clearBill();
    toast.add(`Bill ${bill.billNo} generated!`);
  };

  return (
    <div>
      <div className="topbar">
        <div className="topbar-title">New Bill</div>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-secondary" onClick={clearBill}>Clear</button>
          <button className="btn btn-primary" onClick={generateBill}>Generate Bill →</button>
        </div>
      </div>

      <div className="billing-layout">
        <div className="card billing-menu">
          <div className="menu-controls" style={{ flexDirection: "column", gap: 10 }}>
            <input className="search-input" placeholder="Search menu..." value={search} onChange={e => setSearch(e.target.value)} style={{ width: "100%" }} />
            <div className="cat-filter">
              {["all", ...CATEGORIES].map(c => (
                <button key={c} className={`cat-btn ${catFilter === c ? "active" : ""}`} onClick={() => setCatFilter(c)}>
                  {c === "all" ? "All" : `${CATEGORY_ICONS[c]} ${c}`}
                </button>
              ))}
            </div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 10, marginTop: 16 }}>
            {filtered.map(item => (
              <div key={item.id} className={`menu-item-select ${cart[item.id] ? "in-cart" : ""}`} onClick={() => addToCart(item)}>
                <div className="item-n">{item.name}</div>
                <div className="item-p">{formatCurrency(item.price)}</div>
                <div className="fs-12 text-muted" style={{ marginTop: 4 }}>{CATEGORY_ICONS[item.category]} {item.category}</div>
                {cart[item.id] && <div style={{ marginTop: 6 }}><span className="badge badge-success">×{cart[item.id].qty}</span></div>}
              </div>
            ))}
          </div>
        </div>

        <div className="billing-sidebar-panel">
          <div className="card">
            <div className="card-title" style={{ marginBottom: 16 }}>Current Bill</div>
            <div className="form-group">
              <label>Customer / Table</label>
              <input className="form-control" placeholder="e.g. Table 3 / John" value={customerName} onChange={e => setCustomerName(e.target.value)} />
            </div>
            {cartItems.length === 0 ? (
              <div className="empty-state" style={{ padding: "24px 10px" }}>
                <div className="icon" style={{ fontSize: 32 }}>🛒</div>
                <p style={{ fontSize: 12 }}>Tap items from menu to add</p>
              </div>
            ) : (
              <div>
                {cartItems.map(item => (
                  <div key={item.id} className="bill-item-row">
                    <div style={{ flex: 1 }}>
                      <div className="bill-item-name">{item.name}</div>
                      <div className="bill-item-price">{formatCurrency(item.price)} each</div>
                    </div>
                    <div className="qty-control">
                      <button className="qty-btn" onClick={() => updateQty(item.id, -1)}>−</button>
                      <span className="qty-display">{item.qty}</span>
                      <button className="qty-btn" onClick={() => updateQty(item.id, 1)}>+</button>
                    </div>
                    <div style={{ minWidth: 60, textAlign: "right", fontSize: 13, fontWeight: 600, color: "var(--accent)" }}>
                      {formatCurrency(item.price * item.qty)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="card">
            <div className="form-group mb-16">
              <label>Discount (₹)</label>
              <input className="form-control" type="number" value={discount} onChange={e => setDiscount(e.target.value)} placeholder="0" min="0" />
            </div>
            <div className="bill-total-row"><span>Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
            <div className="bill-total-row"><span>GST (5%)</span><span>{formatCurrency(gst)}</span></div>
            {discAmt > 0 && <div className="bill-total-row text-green"><span>Discount</span><span>−{formatCurrency(discAmt)}</span></div>}
            <div className="bill-total-row grand"><span>Total</span><span className="amt">{formatCurrency(total)}</span></div>
            <div className="section-divider" />
            <div className="fs-12 text-muted" style={{ marginBottom: 8 }}>Payment Mode</div>
            <div className="payment-modes">
              {["cash", "upi", "card"].map(m => (
                <button key={m} className={`pay-mode ${payMode === m ? "active" : ""}`} onClick={() => setPayMode(m)}>
                  {m === "cash" ? "💵" : m === "upi" ? "📱" : "💳"} {m.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {invoiceBill && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setInvoiceBill(null)}>
          <div className="modal invoice-modal">
            <div className="invoice-header">
              <h2>🏨 HotelBill Pro</h2>
              <p style={{ color: "var(--muted)", fontSize: 13 }}>Tax Invoice</p>
            </div>
            <div className="invoice-meta">
              <span><strong>Bill No:</strong> {invoiceBill.billNo}</span>
              <span><strong>Date:</strong> {formatDate(invoiceBill.createdAt)}</span>
              <span><strong>Time:</strong> {formatTime(invoiceBill.createdAt)}</span>
              <span><strong>Customer:</strong> {invoiceBill.customerName}</span>
              <span><strong>Payment:</strong> {invoiceBill.paymentMode.toUpperCase()}</span>
              <span><strong>GSTIN:</strong> 33XXXXX1234X1ZX</span>
            </div>
            <table className="invoice-items-table">
              <thead><tr><th>Item</th><th style={{ textAlign: "center" }}>Qty</th><th style={{ textAlign: "right" }}>Rate</th><th style={{ textAlign: "right" }}>Amount</th></tr></thead>
              <tbody>
                {invoiceBill.items.map((it, i) => (
                  <tr key={i}>
                    <td>{it.name}</td>
                    <td style={{ textAlign: "center" }}>{it.qty}</td>
                    <td style={{ textAlign: "right" }}>{formatCurrency(it.price)}</td>
                    <td style={{ textAlign: "right", fontWeight: 600 }}>{formatCurrency(it.price * it.qty)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="invoice-totals">
              <div className="bill-total-row"><span>Subtotal</span><span>{formatCurrency(invoiceBill.subtotal)}</span></div>
              <div className="bill-total-row"><span>GST @ 5%</span><span>{formatCurrency(invoiceBill.gst)}</span></div>
              {invoiceBill.discount > 0 && <div className="bill-total-row" style={{ color: "var(--green)" }}><span>Discount</span><span>−{formatCurrency(invoiceBill.discount)}</span></div>}
              <div className="bill-total-row grand"><span>Grand Total</span><span className="amt">{formatCurrency(invoiceBill.total)}</span></div>
            </div>
            <div style={{ marginTop: 20, padding: "12px", background: "var(--surface2)", borderRadius: "var(--radius-sm)", fontSize: 11, color: "var(--muted)", textAlign: "center" }}>
              Thank you for dining with us! • This is a computer generated invoice.
            </div>
            <div className="modal-actions no-print">
              <button className="btn btn-secondary" onClick={() => setInvoiceBill(null)}>Close</button>
              <button className="btn btn-primary" onClick={() => window.print()}>🖨️ Print Invoice</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Transactions ──────────────────────────────────────────────────────────────
function Transactions({ bills, setBills, toast }) {
  const [view, setView] = useState(null);
  const [search, setSearch] = useState("");

  const filtered = [...bills]
    .filter(b => b.billNo.toLowerCase().includes(search.toLowerCase()) || b.customerName.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div>
      <div className="topbar">
        <div className="topbar-title">Transactions</div>
        <span className="badge badge-info">{bills.length} bills</span>
      </div>
      <div className="card">
        <input className="search-input" placeholder="Search by bill no or customer..." value={search} onChange={e => setSearch(e.target.value)} style={{ marginBottom: 20, width: "100%", maxWidth: 380 }} />
        {filtered.length === 0 ? (
          <div className="empty-state"><div className="icon">🧾</div><p>No transactions found</p></div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Bill No</th><th>Customer</th><th>Items</th><th>Total</th><th>Payment</th><th>Date & Time</th><th>Actions</th></tr></thead>
              <tbody>
                {filtered.map(b => (
                  <tr key={b.id}>
                    <td className="fw-600 text-accent">{b.billNo}</td>
                    <td>{b.customerName}</td>
                    <td className="text-muted">{b.items.length} items</td>
                    <td className="fw-600">{formatCurrency(b.total)}</td>
                    <td><span className="badge badge-info">{b.paymentMode.toUpperCase()}</span></td>
                    <td className="text-muted fs-12">{formatDate(b.createdAt)} {formatTime(b.createdAt)}</td>
                    <td>
                      <button className="btn btn-secondary btn-sm" onClick={() => setView(b)}>View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {view && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setView(null)}>
          <div className="modal invoice-modal">
            <div className="invoice-header">
              <h2>🏨 HotelBill Pro</h2>
              <p style={{ color: "var(--muted)", fontSize: 13 }}>Tax Invoice</p>
            </div>
            <div className="invoice-meta">
              <span><strong>Bill No:</strong> {view.billNo}</span>
              <span><strong>Date:</strong> {formatDate(view.createdAt)}</span>
              <span><strong>Time:</strong> {formatTime(view.createdAt)}</span>
              <span><strong>Customer:</strong> {view.customerName}</span>
              <span><strong>Payment:</strong> {view.paymentMode.toUpperCase()}</span>
            </div>
            <table className="invoice-items-table">
              <thead><tr><th>Item</th><th style={{ textAlign: "center" }}>Qty</th><th style={{ textAlign: "right" }}>Rate</th><th style={{ textAlign: "right" }}>Amount</th></tr></thead>
              <tbody>
                {view.items.map((it, i) => (
                  <tr key={i}>
                    <td>{it.name}</td>
                    <td style={{ textAlign: "center" }}>{it.qty}</td>
                    <td style={{ textAlign: "right" }}>{formatCurrency(it.price)}</td>
                    <td style={{ textAlign: "right", fontWeight: 600 }}>{formatCurrency(it.price * it.qty)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="invoice-totals">
              <div className="bill-total-row"><span>Subtotal</span><span>{formatCurrency(view.subtotal)}</span></div>
              <div className="bill-total-row"><span>GST @ 5%</span><span>{formatCurrency(view.gst)}</span></div>
              {view.discount > 0 && <div className="bill-total-row" style={{ color: "var(--green)" }}><span>Discount</span><span>−{formatCurrency(view.discount)}</span></div>}
              <div className="bill-total-row grand"><span>Grand Total</span><span className="amt">{formatCurrency(view.total)}</span></div>
            </div>
            <div className="modal-actions">
              <button className="btn btn-secondary" onClick={() => setView(null)}>Close</button>
              <button className="btn btn-primary" onClick={() => window.print()}>🖨️ Print</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Reports ───────────────────────────────────────────────────────────────────
function Reports({ bills }) {
  const [period, setPeriod] = useState("daily");

  const now = Date.now();
  const getBills = () => {
    if (period === "daily") return bills.filter(b => dayStart(b.createdAt) >= dayStart(now));
    if (period === "weekly") return bills.filter(b => b.createdAt >= weekStart());
    return bills.filter(b => b.createdAt >= monthStart());
  };

  const periodBills = getBills();
  const total = periodBills.reduce((s, b) => s + b.total, 0);
  const totalGST = periodBills.reduce((s, b) => s + b.gst, 0);
  const totalDiscount = periodBills.reduce((s, b) => s + b.discount, 0);

  // Item breakdown
  const itemMap = {};
  periodBills.forEach(b => b.items.forEach(it => {
    if (!itemMap[it.name]) itemMap[it.name] = { qty: 0, rev: 0 };
    itemMap[it.name].qty += it.qty;
    itemMap[it.name].rev += it.price * it.qty;
  }));
  const itemReport = Object.entries(itemMap).sort((a, b) => b[1].rev - a[1].rev);

  // Payment mode breakdown
  const payMap = { cash: 0, upi: 0, card: 0 };
  periodBills.forEach(b => { payMap[b.paymentMode] = (payMap[b.paymentMode] || 0) + b.total; });

  const exportCSV = () => {
    const rows = [
      ["Bill No", "Customer", "Date", "Time", "Items", "Subtotal", "GST", "Discount", "Total", "Payment"],
      ...periodBills.map(b => [
        b.billNo, b.customerName, formatDate(b.createdAt), formatTime(b.createdAt),
        b.items.map(i => `${i.name}x${i.qty}`).join("; "),
        b.subtotal, b.gst, b.discount, b.total, b.paymentMode
      ])
    ];
    const csv = rows.map(r => r.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `report-${period}-${today()}.csv`; a.click();
  };

  return (
    <div>
      <div className="topbar">
        <div className="topbar-title">Reports</div>
        <button className="btn btn-success" onClick={exportCSV}>⬇ Export CSV</button>
      </div>

      <div className="report-tabs">
        {["daily", "weekly", "monthly"].map(p => (
          <button key={p} className={`report-tab ${period === p ? "active" : ""}`} onClick={() => setPeriod(p)}>
            {p.charAt(0).toUpperCase() + p.slice(1)}
          </button>
        ))}
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-label">Revenue</div>
          <div className="stat-value text-accent">{formatCurrency(total)}</div>
          <div className="stat-sub">{periodBills.length} bills</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">GST Collected</div>
          <div className="stat-value" style={{ color: "var(--green)" }}>{formatCurrency(totalGST)}</div>
          <div className="stat-sub">@ 5% rate</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Total Discounts</div>
          <div className="stat-value" style={{ color: "var(--red)" }}>{formatCurrency(totalDiscount)}</div>
          <div className="stat-sub">given to customers</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Avg Bill Value</div>
          <div className="stat-value" style={{ color: "var(--blue)" }}>{formatCurrency(periodBills.length ? total / periodBills.length : 0)}</div>
          <div className="stat-sub">per transaction</div>
        </div>
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-title" style={{ marginBottom: 16 }}>Item-wise Revenue</div>
          {itemReport.length === 0 ? <div className="empty-state"><div className="icon">📊</div><p>No data for this period</p></div> : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Item</th><th>Qty</th><th>Revenue</th></tr></thead>
                <tbody>
                  {itemReport.map(([name, data]) => (
                    <tr key={name}>
                      <td className="fw-600">{name}</td>
                      <td><span className="badge badge-info">{data.qty}</span></td>
                      <td className="text-accent fw-600">{formatCurrency(data.rev)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="card">
          <div className="card-title" style={{ marginBottom: 16 }}>Payment Mode Breakdown</div>
          {Object.entries(payMap).map(([mode, amt]) => {
            const pct = total > 0 ? (amt / total) * 100 : 0;
            return (
              <div key={mode} style={{ marginBottom: 16 }}>
                <div className="flex-between mb-16" style={{ marginBottom: 6 }}>
                  <span className="fw-600">{mode.toUpperCase()}</span>
                  <span className="text-accent fw-600">{formatCurrency(amt)}</span>
                </div>
                <div style={{ background: "var(--surface2)", borderRadius: 99, height: 8, overflow: "hidden" }}>
                  <div style={{ background: "var(--accent)", height: "100%", width: `${pct}%`, borderRadius: 99, transition: "width 0.4s" }} />
                </div>
                <div className="fs-12 text-muted" style={{ marginTop: 4 }}>{pct.toFixed(1)}%</div>
              </div>
            );
          })}
          {total === 0 && <div className="empty-state"><div className="icon">💳</div><p>No payments this period</p></div>}
        </div>
      </div>
    </div>
  );
}

// ─── Settings ─────────────────────────────────────────────────────────────────
function Settings({ user, toast }) {
  const [hotelName, setHotelName] = useState("HotelBill Pro");
  const [address, setAddress] = useState("123 Main Street, Madurai, Tamil Nadu");
  const [phone, setPhone] = useState("+91 98765 43210");
  const [gstin, setGstin] = useState("33XXXXX1234X1ZX");
  const [gstEnabled, setGstEnabled] = useState(true);

  return (
    <div>
      <div className="topbar"><div className="topbar-title">Settings</div></div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title" style={{ marginBottom: 20 }}>Hotel Information</div>
          <div className="form-group"><label>Hotel Name</label><input className="form-control" value={hotelName} onChange={e => setHotelName(e.target.value)} /></div>
          <div className="form-group"><label>Address</label><input className="form-control" value={address} onChange={e => setAddress(e.target.value)} /></div>
          <div className="form-group"><label>Phone</label><input className="form-control" value={phone} onChange={e => setPhone(e.target.value)} /></div>
          <div className="form-group"><label>GSTIN</label><input className="form-control" value={gstin} onChange={e => setGstin(e.target.value)} /></div>
          <button className="btn btn-primary" onClick={() => toast.add("Settings saved!")}>Save Changes</button>
        </div>

        <div className="card">
          <div className="card-title" style={{ marginBottom: 20 }}>Billing Settings</div>
          <div className="flex-between" style={{ marginBottom: 16, padding: "12px 0", borderBottom: "1px solid var(--border)" }}>
            <div><div className="fw-600">GST @ 5%</div><div className="fs-12 text-muted">Apply GST on all bills</div></div>
            <label className="toggle"><input type="checkbox" checked={gstEnabled} onChange={e => setGstEnabled(e.target.checked)} /><div className="toggle-slider" /></label>
          </div>
          <div className="flex-between" style={{ marginBottom: 16, padding: "12px 0", borderBottom: "1px solid var(--border)" }}>
            <div><div className="fw-600">Auto Bill Number</div><div className="fs-12 text-muted">Auto-generate invoice numbers</div></div>
            <label className="toggle"><input type="checkbox" defaultChecked /><div className="toggle-slider" /></label>
          </div>
          <div className="flex-between" style={{ padding: "12px 0" }}>
            <div><div className="fw-600">Print on Save</div><div className="fs-12 text-muted">Auto open print dialog</div></div>
            <label className="toggle"><input type="checkbox" /><div className="toggle-slider" /></label>
          </div>
          <div style={{ marginTop: 16 }}>
            <div className="fs-12 text-muted mb-16">Logged in as</div>
            <div className="flex gap-8">
              <div className="user-avatar" style={{ width: 40, height: 40 }}>{user.name[0]}</div>
              <div><div className="fw-600">{user.name}</div><div className="fs-12 text-muted">{user.username} · {user.role}</div></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── App Shell ─────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState("dashboard");
  const [menu, setMenu] = useState(INITIAL_MENU);
  const [bills, setBills] = useState(generateSeedBills);
  const toast = useToast();

  const handleLogin = (u) => setUser(u);
  const handleLogout = () => { setUser(null); setPage("dashboard"); };

  if (!user) return (
    <>
      <style>{CSS}</style>
      <Login onLogin={handleLogin} />
    </>
  );

  return (
    <>
      <style>{CSS}</style>
      <div className="app-layout">
        <Sidebar page={page} setPage={setPage} user={user} onLogout={handleLogout} billCount={0} />
        <main className="main-content">
          {page === "dashboard" && <Dashboard bills={bills} menu={menu} />}
          {page === "menu" && <MenuManagement menu={menu} setMenu={setMenu} user={user} toast={toast} />}
          {page === "billing" && <Billing menu={menu} bills={bills} setBills={setBills} toast={toast} />}
          {page === "transactions" && <Transactions bills={bills} setBills={setBills} toast={toast} />}
          {page === "reports" && <Reports bills={bills} />}
          {page === "settings" && <Settings user={user} toast={toast} />}
        </main>
      </div>
      <Toast toasts={toast.toasts} removeToast={toast.remove} />
    </>
  );
}
